window.ARENA_CFG={brand:"TCS NQT Practice Arena",sub:"Online Learning Team | 2027 batch",passMark:60,speed:1,
 compiler:{backends:[
  {type:"judge0",url:"https://ce.judge0.com",headers:{},langs:{c:50,cpp:54,java:62,python:71},cpuSec:5,memKB:256000},
  {type:"piston",url:"https://emkc.org/api/v2/piston",langs:{c:"c",cpp:"c++",java:"java",python:"python"}}
 ]}};
