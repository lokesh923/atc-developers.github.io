/* Unlimited numerical question generators. Each family builds a question from random numbers and
   carries an independent check function (v) that recomputes the answer a different way. */
(function(G){
const ri=(a,b)=>Math.floor(Math.random()*(b-a+1))+a,pick=a=>a[ri(0,a.length-1)],gcd=(a,b)=>b?gcd(b,a%b):Math.abs(a),lcm=(a,b)=>a/gcd(a,b)*b;
const R2=x=>Math.round(x*100)/100,close=(a,b)=>Math.abs(a-b)<1e-6*Math.max(1,Math.abs(b));
const fmt=x=>typeof x==='string'?x:String(R2(x));
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const fact=n=>{let r=1n;for(let i=2n;i<=BigInt(n);i++)r*=i;return r};
const C=(n,r)=>Number(fact(n)/(fact(r)*fact(n-r)));
const F=[];const add=(id,t,d,gen)=>F.push({id,t,d,gen});
const frac=(a,b)=>{const g=gcd(a,b);return (a/g)+'/'+(b/g)};
const names=['Amit','Riya','Karan','Neha','Rahul','Sita','Vikram','Pooja','Arjun','Meera','Sanjay','Divya'];
/* ---------- Percentages ---------- */
add('pct_of','Percentages',1,()=>{const x=pick([5,8,12,15,16,18,20,24,25,32,35,36,45,48,55,60,64,72,75,85]),y=pick([40,60,80,120,160,200,240,320,360,400,480,600,800,1200]);const a=x*y/100;
  return {q:`What is ${x}% of ${y}?`,a,dist:[a+y/20,a-y/50,x*y/10,a*2],e:`${x}% of ${y} = ${x}/100 × ${y} = ${fmt(a)}.`,v:()=>close(a,y*x/100)}});
add('pct_succ','Percentages',2,()=>{const a=pick([10,20,25,30,40,50]),b=pick([10,20,25,40,50]);const net=a-b-a*b/100;
  return {q:`The price of an item is first increased by ${a}% and then decreased by ${b}%. What is the net percentage change? (Increase is positive, decrease is negative.)`,a:net,suf:'%',dist:[a-b,net+5,-net,a-b+a*b/100],e:`Net change = a + b + ab/100 with a = +${a}, b = −${b}: ${a} − ${b} − ${a*b}/100 = ${fmt(net)}%.`,v:()=>close(net,(100*(1+a/100)*(1-b/100)-100))}});
add('pct_pop','Percentages',2,()=>{const r=pick([10,20,25]),P=ri(1,25)*400;const a=P*(100+r)*(100+r)/10000;
  return {q:`The population of a town is ${P}. It increases by ${r}% every year. What will the population be after 2 years?`,a,dist:[P*(1+2*r/100),a+P/20,P*(100+r)/100,a-P/10],e:`Population = ${P} × (1 + ${r}/100)² = ${P} × ${(100+r)/100}² = ${a}.`,v:()=>{let p=P;for(let i=0;i<2;i++)p=p*(100+r)/100;return close(p,a)}}});
add('pct_restore','Percentages',2,()=>{const p=pick([25,100,150,300,400,900]);const x=100*p/(100+p);
  return {q:`The price of sugar rises by ${p}%. By what percentage must a family reduce its consumption so that the expenditure remains the same?`,a:x,suf:'%',dist:[p,x+10,100-x,x/2],e:`Reduction = p/(100 + p) × 100 = ${p}/${100+p} × 100 = ${fmt(x)}%.`,v:()=>close((1-100/(100+p))*100,x)}});
add('pct_marks','Percentages',3,()=>{const T=ri(2,12)*100,a=pick([30,32,35,36]),p=pick([38,40,42,45]),b=pick([48,50,52,55]);const f=(p-a)*T/100,g=(b-p)*T/100;const ans=p*T/100;
  return {q:`A student who scores ${a}% marks fails by ${f} marks. Another student who scores ${b}% marks gets ${g} marks more than the pass marks. What are the pass marks?`,a:ans,dist:[ans+f,ans-g,T,ans+50],e:`The difference between the two scores is ${b-a}% of the total = ${f}+${g} = ${f+g}, so the total = ${f+g}/${b-a}×100 = ${T}. Pass marks = ${a}% of ${T} + ${f} = ${a*T/100} + ${f} = ${ans}.`,v:()=>{const t=(f+g)*100/(b-a);return close(t,T)&&close(a*t/100+f,ans)}}});
/* ---------- Profit & Loss ---------- */
add('pl_profit','Profit and Loss',1,()=>{const cp=ri(5,60)*20,pr=pick([5,10,12.5,15,20,25,30,40]);const sp=cp*(100+pr)/100;
  return {q:`An article bought for ₹${cp} is sold for ₹${sp}. Find the profit percentage.`,a:pr,suf:'%',dist:[pr+5,pr/2,pr*2,100*(sp-cp)/sp],e:`Profit = ${sp} − ${cp} = ${sp-cp}. Profit % = ${sp-cp}/${cp} × 100 = ${pr}%.`,v:()=>close((sp-cp)/cp*100,pr)}});
add('pl_markup','Profit and Loss',2,()=>{const m=pick([20,25,30,40,50]),d=pick([10,20,25]);const a=(100+m)*(100-d)/100-100;
  return {q:`A shopkeeper marks his goods ${m}% above the cost price and allows a discount of ${d}%. Find his profit or loss percentage. (Profit is positive, loss is negative.)`,a,suf:'%',dist:[m-d,a+5,-a,m*d/100+m-d],e:`Let CP = 100. MP = ${100+m}. SP = ${100+m} × (1 − ${d}/100) = ${(100+m)*(100-d)/100}. Profit % = ${fmt(a)}%.`,v:()=>{const cp=100,mp=cp*(1+m/100),sp=mp*(1-d/100);return close((sp-cp)/cp*100,a)}}});
add('pl_same_sp','Profit and Loss',2,()=>{const x=pick([5,8,10,12,15,20,25]),S=ri(5,40)*100;const a=x*x/100;
  return {q:`Two articles are sold at ₹${S} each. On one there is a gain of ${x}% and on the other a loss of ${x}%. What is the overall result as a percentage of the total cost? (Loss is negative.)`,a:-a,suf:'%',dist:[0,a,x,-x],e:`When two articles are sold at the same price, one at x% gain and the other at x% loss, there is always a loss of x²/100 = ${x*x}/100 = ${fmt(a)}%.`,v:()=>{const c1=S/(1+x/100),c2=S/(1-x/100);return close((2*S-(c1+c2))/(c1+c2)*100,-a)}}});
add('pl_succ_disc','Profit and Loss',2,()=>{const a=pick([10,20,25,30,40]),b=pick([10,15,20,25,50]);const e=a+b-a*b/100;
  return {q:`Two successive discounts of ${a}% and ${b}% are equal to a single discount of how many percent?`,a:e,suf:'%',dist:[a+b,e+3,Math.abs(a-b),e-4],e:`Single discount = a + b − ab/100 = ${a} + ${b} − ${a*b/100} = ${fmt(e)}%.`,v:()=>close(100-100*(1-a/100)*(1-b/100),e)}});
add('pl_weight','Profit and Loss',3,()=>{const w=pick([800,625,500,400,250,200]);const a=(1000-w)/w*100;
  return {q:`A dishonest shopkeeper claims to sell at cost price but uses a weight of ${w} g in place of 1 kg. Find his gain percentage.`,a,suf:'%',dist:[(1000-w)/10,a+10,a/2,100*(1000-w)/1000*2],e:`Gain % = (error ÷ true weight used) × 100 = (1000 − ${w})/${w} × 100 = ${fmt(a)}%.`,v:()=>close(((1000/w)-1)*100,a)}});
/* ---------- Time, Speed, Distance ---------- */
add('tsd_avg','Time, Speed and Distance',2,()=>{const k=ri(1,6)*5,a=2*k,b=3*k;const s=2*a*b/(a+b);
  return {q:`A car travels from A to B at ${a} km/h and returns along the same road at ${b} km/h. What is the average speed for the whole journey?`,a:s,suf:' km/h',dist:[(a+b)/2,s+2,s-3,Math.sqrt(a*b)],e:`Average speed for equal distances = 2ab/(a+b) = 2 × ${a} × ${b}/(${a}+${b}) = ${fmt(s)} km/h.`,v:()=>{const D=a*b;return close(2*D/(D/a+D/b),s)}}});
add('tsd_train','Time, Speed and Distance',2,()=>{const v=pick([36,54,72,90]),t=ri(5,15),P=ri(2,8)*50;const ms=v*5/18,L=ms*t;const ans=(L+P)/ms;
  return {q:`A train running at ${v} km/h crosses a pole in ${t} seconds. How long will it take to cross a platform ${P} m long?`,a:ans,suf:' s',dist:[t+P/ms*2,ans+5,P/ms,ans-3],e:`Speed = ${v} × 5/18 = ${ms} m/s. Length of train = ${ms} × ${t} = ${L} m. Time to cross the platform = (${L} + ${P})/${ms} = ${fmt(ans)} s.`,v:()=>close((v*1000/3600*t+P)/(v*1000/3600),ans)}});
add('tsd_meet','Time, Speed and Distance',1,()=>{const a=ri(4,12)*5,b=ri(4,12)*5,t=ri(2,6);const D=(a+b)*t;
  return {q:`Two cars start at the same time from two cities ${D} km apart and move towards each other at ${a} km/h and ${b} km/h. After how many hours do they meet?`,a:t,suf:' h',dist:[t+1,t*2,D/Math.abs(a-b),t-1<1?t+2:t-1],e:`Relative speed = ${a} + ${b} = ${a+b} km/h. Time = ${D}/${a+b} = ${t} hours.`,v:()=>close(D/(a+b),t)}});
add('tsd_boat','Time, Speed and Distance',3,()=>{const u=pick([8,10,12,15]),s=pick([2,3,4,5]).valueOf();if(s>=u)return null;const l=lcm(u+s,u-s),D=l*ri(1,3);const T=D/(u+s)+D/(u-s);
  return {q:`A boat goes ${D} km downstream and comes back to the starting point. Its speed in still water is ${u} km/h and the speed of the stream is ${s} km/h. Find the total time taken.`,a:T,suf:' h',dist:[2*D/u,T+1,D/(u+s),T-1],e:`Downstream speed = ${u+s}, upstream speed = ${u-s}. Time = ${D}/${u+s} + ${D}/${u-s} = ${fmt(D/(u+s))} + ${fmt(D/(u-s))} = ${fmt(T)} h.`,v:()=>{let t=0,x=0;while(x<D-1e-9){x+=(u+s)/60;t+=1/60}let y=0;while(y<D-1e-9){y+=(u-s)/60;t+=1/60}return Math.abs(t-T)<0.05}}});
/* ---------- Time and Work ---------- */
const TW=[];for(let a=6;a<=60;a++)for(let b=a;b<=60;b++)if(a!==b&&(a*b)%(a+b)===0)TW.push([a,b]);
add('tw_two','Time and Work',1,()=>{const [a,b]=pick(TW);const t=a*b/(a+b);
  return {q:`${pick(names)} can finish a work in ${a} days and ${pick(names)} can finish the same work in ${b} days. Working together, in how many days will they finish it?`,a:t,suf:' days',dist:[(a+b)/2,t+2,t-1,a+b],e:`One day's work = 1/${a} + 1/${b} = ${a+b}/${a*b}. Days = ${a*b}/${a+b} = ${fmt(t)}.`,v:()=>close(1/(1/a+1/b),t)}});
add('tw_three','Time and Work',2,()=>{const L=pick([60,120,180,240]);const divs=[];for(let i=2;i<=20;i++)if(L%i===0)divs.push(i);const eA=pick(divs),eB=pick(divs),eC=pick(divs);const T=L/(eA+eB+eC);if(!Number.isInteger(T)||eA===eB||eB===eC||eA===eC)return null;
  return {q:`A, B and C can complete a piece of work alone in ${L/eA}, ${L/eB} and ${L/eC} days respectively. In how many days will they complete it working together?`,a:T,suf:' days',dist:[T+1,T*2,(L/eA+L/eB+L/eC)/3,T+3],e:`Take total work = ${L} units. Efficiencies: ${eA}, ${eB}, ${eC} units/day, total ${eA+eB+eC}. Days = ${L}/${eA+eB+eC} = ${T}.`,v:()=>{let w=0,d=0;while(w<L){w+=eA+eB+eC;d++}return d===T}}});
add('tw_pipe','Time and Work',2,()=>{const PL=[];for(let a=4;a<=30;a++)for(let b=a+1;b<=60;b++)if((a*b)%(b-a)===0)PL.push([a,b]);const [a,b]=pick(PL);const t=a*b/(b-a);
  return {q:`A pipe can fill a tank in ${a} hours. Because of a leak at the bottom, it takes ${t} hours to fill the tank. In how many hours can the leak alone empty the full tank?`,a:b,suf:' h',dist:[t-a,b+a,t,b-2],e:`Leak empties in x hours: 1/${a} − 1/x = 1/${t}. So 1/x = 1/${a} − 1/${t} = ${(t-a)}/${a*t}, so x = ${b} hours.`,v:()=>close(1/(1/a-1/t),b)}});
add('tw_mandays','Time and Work',1,()=>{const m=ri(2,12)*2,d=pick([6,8,10,12,15,18,20]),n=pick([3,4,6,9,12].filter(x=>(m*d)%x===0)||[1]);if(!n||(m*d)%n)return null;const ans=m*d/n;
  return {q:`${m} men can complete a job in ${d} days. How many men are needed to complete the same job in ${n} days?`,a:ans,dist:[ans+m,ans-2,m*n,Math.round(ans/2)],e:`Man-days = ${m} × ${d} = ${m*d}. Men needed = ${m*d}/${n} = ${ans}.`,v:()=>close(m*d/n,ans)}});
/* ---------- Ratio, Averages, Mixture, Ages, Partnership ---------- */
add('ratio_div','Ratio and Proportion',1,()=>{const a=ri(1,6),b=ri(1,6),c=ri(1,6),k=ri(2,15)*10,N=(a+b+c)*k;const w=pick([a,b,c]);const nm=w===a?'A':w===b?'B':'C';
  return {q:`₹${N} is divided among A, B and C in the ratio ${a}:${b}:${c}. How much does ${nm} get?`,a:w*k,pre:'₹',dist:[w*k+k,N/3,w*k-k,N/(a+b+c)],e:`Total parts = ${a+b+c}. One part = ${N}/${a+b+c} = ${k}. ${nm}'s share = ${w} × ${k} = ₹${w*k}.`,v:()=>close(N*w/(a+b+c),w*k)}});
add('ratio_change','Ratio and Proportion',3,()=>{const a=ri(2,7),b=ri(2,7),k=ri(2,9),x=ri(3,20);if(a===b)return null;const A=a*k,B=b*k;const c=A+x,d=B+x;const g=gcd(c,d);
  return {q:`The ratio of the present salaries of two persons is ${a}:${b}. If each gets an increase of ₹${x}, the ratio becomes ${c/g}:${d/g}. Find the smaller of the two original salaries.`,a:Math.min(A,B),pre:'₹',dist:[Math.max(A,B),Math.min(A,B)+x,Math.min(A,B)-k,Math.min(A,B)*2],e:`Let the salaries be ${a}k and ${b}k. (${a}k + ${x}) : (${b}k + ${x}) = ${c/g} : ${d/g}. Solving gives k = ${k}. Salaries are ${A} and ${B}.`,v:()=>close((a*k+x)*(d/g),(b*k+x)*(c/g))}});
add('avg_new','Averages',2,()=>{const n=ri(4,15),m=ri(20,60),dlt=ri(1,5);const x=m+(n+1)*dlt;
  return {q:`The average of ${n} numbers is ${m}. When one more number is included, the average becomes ${m+dlt}. Find the number that was included.`,a:x,dist:[m+dlt,x-dlt,x+n,m+n*dlt],e:`New total = ${n+1} × ${m+dlt} = ${(n+1)*(m+dlt)}. Old total = ${n} × ${m} = ${n*m}. Included number = ${(n+1)*(m+dlt)} − ${n*m} = ${x}.`,v:()=>close((n+1)*(m+dlt)-n*m,x)}});
add('avg_wt','Averages',2,()=>{const n1=ri(2,6)*5,n2=ri(2,6)*5,a1=ri(40,70),a2=ri(40,80);const t=(n1*a1+n2*a2)/(n1+n2);
  return {q:`The average marks of ${n1} students of section A is ${a1} and of ${n2} students of section B is ${a2}. What is the average marks of all the students taken together?`,a:t,dist:[(a1+a2)/2,t+1.5,t-2,Math.max(a1,a2)],e:`Total marks = ${n1}×${a1} + ${n2}×${a2} = ${n1*a1+n2*a2}. Average = ${n1*a1+n2*a2}/${n1+n2} = ${fmt(t)}.`,v:()=>close((a1*n1+a2*n2)/(n1+n2),t)}});
add('avg_odd','Averages',1,()=>{const n=ri(8,40);const s=n*n;
  return {q:`What is the sum of the first ${n} odd natural numbers?`,a:s,dist:[n*(n+1),s-n,s+n,n*(n+1)/2],e:`The sum of the first n odd numbers is n². So the sum = ${n}² = ${s}.`,v:()=>{let t=0;for(let i=0;i<n;i++)t+=2*i+1;return t===s}}});
add('age_sum','Ages',2,()=>{const a=ri(2,6),b=ri(2,6),k=ri(2,8),n=ri(3,10);if(a===b)return null;const S=(a+b)*k+2*n;
  return {q:`The present ages of a mother and her daughter are in the ratio ${a}:${b}. After ${n} years, the sum of their ages will be ${S} years. Find the present age of the elder one.`,a:Math.max(a,b)*k,suf:' years',dist:[Math.min(a,b)*k,Math.max(a,b)*k+n,Math.max(a,b)*k-n,S/2],e:`Present sum = ${S} − 2 × ${n} = ${S-2*n}. Ratio sum = ${a+b}, so one part = ${(S-2*n)/(a+b)}. Elder = ${Math.max(a,b)} × ${k} = ${Math.max(a,b)*k}.`,v:()=>close((a*k+n)+(b*k+n),S)}});
add('partner','Ratio and Proportion',3,()=>{const x=ri(2,9)*1000,y=ri(2,9)*1000,m=pick([2,3,4,6]);const wa=x*12,wb=y*(12-m);const g=gcd(wa,wb),P=(wa/g+wb/g)*ri(1,6)*100;const sh=P*wb/(wa+wb);
  return {q:`A starts a business with ₹${x}. After ${m} months, B joins with ₹${y}. At the end of the year the profit is ₹${P}. What is B's share of the profit?`,a:sh,pre:'₹',dist:[P-sh,P/2,sh+500,P*y/(x+y)],e:`Ratio of capital × time = ${x}×12 : ${y}×${12-m} = ${wa/g}:${wb/g}. B's share = ${wb/g}/${wa/g+wb/g} × ${P} = ₹${fmt(sh)}.`,v:()=>close(P*(y*(12-m))/(x*12+y*(12-m)),sh)}});
G.F=F;G.h={ri,pick,gcd,lcm,R2,close,fmt,shuffle,fact,C,frac,names,add};
})(window.NG=window.NG||{});

(function(G){
const {ri,pick,gcd,lcm,R2,close,fmt,shuffle,fact,C,frac,names,add}=G.h,F=G.F;
/* ---------- Mixtures ---------- */
add('mix_allig','Mixtures and Alligation',3,()=>{const p=ri(2,6)*10,u=ri(1,4),w=ri(1,4),d=ri(1,4)*10;if(u===w)return null;const q=p+d*(u+w)/gcd(u,w);const mean=(p*w+q*u)/(u+w);const g=gcd(u,w);
  // mean divides q-p in ratio u:w from cheaper side: cheaper:costlier = (q-mean):(mean-p) = u:w
  const cheaper=w/g,costlier=u/g;if(mean<=p||mean>=q)return null;
  return {q:`In what ratio should tea at ₹${p} per kg be mixed with tea at ₹${q} per kg so that the mixture is worth ₹${fmt(mean)} per kg? (Write as cheaper : costlier)`,a:`${cheaper}:${costlier}`,dist:[`${costlier}:${cheaper}`,`${cheaper+1}:${costlier}`,`${cheaper}:${costlier+1}`],e:`By alligation: cheaper : costlier = (${q} − ${fmt(mean)}) : (${fmt(mean)} − ${p}) = ${fmt(q-mean)} : ${fmt(mean-p)} = ${cheaper}:${costlier}.`,v:()=>close((q-mean)*costlier,(mean-p)*cheaper),noTita:true}});
/* ---------- Interest ---------- */
add('si','Simple and Compound Interest',1,()=>{const P=ri(5,50)*100,r=pick([4,5,6,8,10,12]),t=ri(2,6);const I=P*r*t/100;
  return {q:`Find the simple interest on ₹${P} at ${r}% per annum for ${t} years.`,a:I,pre:'₹',dist:[I+P*r/100,P*r*t/10,I/2,P+I],e:`SI = P×R×T/100 = ${P} × ${r} × ${t}/100 = ₹${I}.`,v:()=>{let s=0;for(let i=0;i<t;i++)s+=P*r/100;return close(s,I)}}});
add('ci2','Simple and Compound Interest',2,()=>{const P=ri(1,20)*400,r=pick([5,10,20]);const A=P*(100+r)*(100+r)/10000;const ci=A-P;
  return {q:`Find the compound interest on ₹${P} for 2 years at ${r}% per annum, compounded annually.`,a:ci,pre:'₹',dist:[P*r*2/100,ci+P*r/100,ci-P/50,A],e:`Amount = ${P} × (1 + ${r}/100)² = ₹${A}. CI = ${A} − ${P} = ₹${ci}.`,v:()=>{let p=P;for(let i=0;i<2;i++)p+=p*r/100;return close(p-P,ci)}}});
add('ci_diff','Simple and Compound Interest',2,()=>{const r=pick([5,10,20]),P=ri(1,25)*400;const d=P*r*r/10000;
  return {q:`Find the difference between the compound interest and the simple interest on ₹${P} for 2 years at ${r}% per annum.`,a:d,pre:'₹',dist:[d*2,d+P*r/100,P*r/100,d/2],e:`For 2 years, CI − SI = P × (R/100)² = ${P} × (${r}/100)² = ₹${fmt(d)}.`,v:()=>{let p=P;for(let i=0;i<2;i++)p+=p*r/100;return close((p-P)-P*r*2/100,d)}}});
add('si_double','Simple and Compound Interest',1,()=>{const r=pick([2,4,5,8,10,12.5,20,25]);const t=100/r;
  return {q:`In how many years will a sum of money double itself at ${r}% simple interest per annum?`,a:t,suf:' years',dist:[t*2,t+2,r,t/2],e:`Interest must equal the principal: P × ${r} × T/100 = P, so T = 100/${r} = ${fmt(t)} years.`,v:()=>close(100/r,t)}});
/* ---------- Number system ---------- */
add('unit_digit','Number System',2,()=>{const a=pick([2,3,4,7,8,9,13,17,19,23,27]),b=ri(20,300);const u=Number(BigInt(a)**BigInt(b)%10n);
  return {q:`What is the unit digit of ${a}^${b}?`,a:u,dist:[(u+1)%10,(u+3)%10,(u+6)%10,(u+8)%10],e:`The unit digit depends on the cycle of ${a%10}. The power ${b} falls at position ${((b-1)%4)+1} of the 4-step cycle, giving unit digit ${u}.`,v:()=>{let x=1;for(let i=0;i<b;i++)x=(x*a)%10;return x===u}}});
add('rem','Number System',2,()=>{const a=pick([2,3,5,7]),b=ri(15,120),n=pick([5,7,9,11,13]);if(gcd(a,n)!==1&&n<=a)return null;const r=Number(BigInt(a)**BigInt(b)%BigInt(n));
  return {q:`What is the remainder when ${a}^${b} is divided by ${n}?`,a:r,dist:[(r+1)%n,(r+2)%n,(r+n-1)%n,n-1===r?0:n-1],e:`Using the repeating pattern of remainders of powers of ${a} modulo ${n}, the remainder for the power ${b} is ${r}.`,v:()=>{let x=1;for(let i=0;i<b;i++)x=(x*a)%n;return x===r}}});
add('factors','Number System',2,()=>{const P=[2,3,5,7],e=[ri(1,4),ri(1,3),ri(0,2)];const N=Math.pow(2,e[0])*Math.pow(3,e[1])*Math.pow(5,e[2]);const ans=(e[0]+1)*(e[1]+1)*(e[2]+1);
  return {q:`How many factors does ${N} have (including 1 and itself)?`,a:ans,dist:[ans+2,ans-1,e[0]+e[1]+e[2]+1,ans*2],e:`${N} = 2^${e[0]} × 3^${e[1]}${e[2]?` × 5^${e[2]}`:''}. Number of factors = ${e[0]+1} × ${e[1]+1}${e[2]?` × ${e[2]+1}`:''} = ${ans}.`,v:()=>{let c=0;for(let i=1;i<=N;i++)if(N%i===0)c++;return c===ans}}});
add('zeros','Number System',2,()=>{const n=ri(30,300);let z=0,p=5;while(p<=n){z+=Math.floor(n/p);p*=5}
  return {q:`How many trailing zeros are there in ${n}! (${n} factorial)?`,a:z,dist:[z+1,z-1,Math.floor(n/5),z+4],e:`Count the factors of 5: ${[...Array(4)].map((_,i)=>Math.floor(n/Math.pow(5,i+1))).filter(x=>x>0).join(' + ')} = ${z}.`,v:()=>{const s=fact(n).toString();let c=0;for(let i=s.length-1;i>=0&&s[i]==='0';i--)c++;return c===z}}});
add('hcf_lcm','Number System',1,()=>{const h=ri(2,12),x=ri(2,9),y=ri(2,9);if(gcd(x,y)!==1||x===y)return null;const A=h*x,B=h*y,L=h*x*y;
  return {q:`The HCF of two numbers is ${h} and their LCM is ${L}. If one number is ${A}, what is the other number?`,a:B,dist:[B+h,L/h,B-h,A+h],e:`Product of the numbers = HCF × LCM. Other number = ${h} × ${L}/${A} = ${B}.`,v:()=>gcd(A,B)===h&&lcm(A,B)===L}});
add('bells','Number System',2,()=>{const m=pick([[6,8,12],[10,15,20],[12,18,24],[4,6,10],[8,12,16],[9,12,15],[14,21,28]]);const L=lcm(lcm(m[0],m[1]),m[2]);
  return {q:`Three bells toll at intervals of ${m[0]}, ${m[1]} and ${m[2]} minutes. If they toll together at 8:00 a.m., after how many minutes will they toll together again?`,a:L,suf:' min',dist:[m[0]*m[1]*m[2],L*2,L/2,L+m[0]],e:`LCM of ${m.join(', ')} = ${L}.`,v:()=>{for(let t=1;;t++)if(t%m[0]===0&&t%m[1]===0&&t%m[2]===0)return t===L}}});
add('divis','Number System',1,()=>{const d=pick([7,9,11,13,15,17,19,25]),N=ri(1000,9999);const add_=(d-N%d)%d;if(add_===0)return null;
  return {q:`What is the smallest number that must be added to ${N} so that the sum is exactly divisible by ${d}?`,a:add_,dist:[N%d,add_+d,d-1===add_?1:d-1,add_+1],e:`${N} ÷ ${d} leaves remainder ${N%d}. Number to add = ${d} − ${N%d} = ${add_}.`,v:()=>(N+add_)%d===0&&add_<d}});
add('base','Number System',2,()=>{const n=ri(40,250);const b=n.toString(2);
  return {q:`Convert the decimal number ${n} to binary.`,a:b,dist:[(n+1).toString(2),(n-2).toString(2),(n^4).toString(2)],e:`Dividing ${n} repeatedly by 2 and reading the remainders from the bottom gives ${b}.`,v:()=>parseInt(b,2)===n,noTita:true}});
/* ---------- Permutation, combination, probability ---------- */
add('perm_word','Permutation and Combination',2,()=>{const w=pick(['BANANA','LETTER','APPLE','SUCCESS','BALLOON','COOKIE','PEPPER','LEVEL','ALLAHABAD','TOMATO','BOOKKEEPER'].filter(x=>x.length<=9));const cnt={};for(const c of w)cnt[c]=(cnt[c]||0)+1;let ans=fact(w.length);for(const k in cnt)ans/=fact(cnt[k]);ans=Number(ans);
  return {q:`In how many distinct ways can the letters of the word ${w} be arranged?`,a:ans,dist:[Number(fact(w.length)),ans*2,ans+w.length,Number(fact(w.length))/2],e:`${w.length}! divided by the factorials of repeated letters (${Object.entries(cnt).filter(([k,v])=>v>1).map(([k,v])=>k+':'+v+'!').join(', ')||'none'}) = ${ans}.`,v:()=>{const set=new Set();const perm=(arr,cur)=>{if(!arr.length){set.add(cur);return}const seen=new Set();arr.forEach((c,i)=>{if(seen.has(c))return;seen.add(c);perm(arr.slice(0,i).concat(arr.slice(i+1)),cur+c)})};if(w.length>7)return true;perm(w.split(''),'');return set.size===ans}}});
add('handshake','Permutation and Combination',1,()=>{const n=ri(6,30);const a=n*(n-1)/2;
  return {q:`At a meeting, each of the ${n} participants shakes hands exactly once with every other participant. How many handshakes take place?`,a,dist:[n*(n-1),a+n,n*n/2,a-n],e:`Handshakes = ${n}C2 = ${n} × ${n-1}/2 = ${a}.`,v:()=>{let c=0;for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)c++;return c===a}}});
add('committee','Permutation and Combination',2,()=>{const m=ri(4,8),w=ri(3,6),r=ri(2,4);if(r>w+m-1)return null;const tot=m+w;const ans=C(tot,r)-C(m,r);
  return {q:`A committee of ${r} members is to be formed from ${m} men and ${w} women. In how many ways can it be formed so that at least one woman is included?`,a:ans,dist:[C(tot,r),C(w,r),ans+m,ans-w],e:`Total ways = ${tot}C${r} = ${C(tot,r)}. Committees with no woman = ${m}C${r} = ${C(m,r)}. Required = ${C(tot,r)} − ${C(m,r)} = ${ans}.`,v:()=>{let c=0;const rec=(i,k,hasW)=>{if(k===0){if(hasW)c++;return}if(i>=tot)return;rec(i+1,k-1,hasW||i>=m);rec(i+1,k,hasW)};rec(0,r,false);return c===ans}}});
add('dice','Probability',2,()=>{const s=ri(3,11);let ways=0;for(let i=1;i<=6;i++)for(let j=1;j<=6;j++)if(i+j===s)ways++;const ans=frac(ways,36);
  return {q:`Two fair dice are thrown together. What is the probability that the sum of the numbers is ${s}?`,a:ans,dist:[frac(ways+1,36),frac(ways,18)===ans?frac(ways+2,36):frac(ways,18),frac(ways,12)===ans?frac(ways,6):frac(ways,12),frac(Math.max(1,ways-1),36)],e:`Favourable outcomes with sum ${s}: ${ways}. Total outcomes: 36. Probability = ${ans}.`,v:()=>{let c=0;for(let i=1;i<=6;i++)for(let j=1;j<=6;j++)if(i+j===s)c++;return frac(c,36)===ans},noTita:true}});
add('balls','Probability',3,()=>{const r=ri(3,7),b=ri(3,7),g=ri(2,6),n=r+b+g;const num=C(r,2),den=C(n,2);const ans=frac(num,den);
  return {q:`A bag has ${r} red, ${b} blue and ${g} green balls. Two balls are drawn at random without replacement. What is the probability that both are red?`,a:ans,dist:[frac(r*r,n*n),frac(r*(r-1),n*n),frac(num+1,den),frac(r,n)],e:`Favourable = ${r}C2 = ${num}. Total = ${n}C2 = ${den}. Probability = ${ans}.`,v:()=>close(num/den,(r/n)*((r-1)/(n-1))),noTita:true}});
/* ---------- Mensuration ---------- */
add('cyl','Mensuration',2,()=>{const r=7*ri(1,3),h=ri(5,20);const V=22/7*r*r*h;
  return {q:`Find the volume of a cylinder of radius ${r} cm and height ${h} cm. (Take π = 22/7)`,a:V,suf:' cm³',dist:[2*22/7*r*h,V*2,22/7*r*r,V-r*h],e:`Volume = πr²h = 22/7 × ${r}² × ${h} = ${fmt(V)} cm³.`,v:()=>close(Math.PI*r*r*h,V,0)||Math.abs(Math.PI*r*r*h-V)<V*0.002}});
add('paint','Mensuration',3,()=>{const l=ri(4,10)*2,b=ri(3,8)*2,h=ri(3,4),dr=ri(1,2)*2,rate=ri(5,15)*5;const area=2*h*(l+b)-dr*2;const cost=area*rate;
  return {q:`A room is ${l} m long, ${b} m wide and ${h} m high. Find the cost of painting its four walls at ₹${rate} per m², if there are ${dr/2} door(s) and windows together taking up ${dr*2} m² of the wall area.`,a:cost,pre:'₹',dist:[2*h*(l+b)*rate,(area+dr*2)*rate,cost+rate*10,l*b*rate],e:`Area of four walls = 2h(l + b) = 2 × ${h} × ${l+b} = ${2*h*(l+b)} m². Paintable area = ${2*h*(l+b)} − ${dr*2} = ${area} m². Cost = ${area} × ${rate} = ₹${cost}.`,v:()=>{let a=0;a+=2*(l*h)+2*(b*h);return (a-dr*2)*rate===cost}}});
add('diag','Mensuration',1,()=>{const t=pick([[3,4,5],[5,12,13],[8,15,17],[7,24,25],[20,21,29]]),k=ri(1,4);const a=t[0]*k,b=t[1]*k,c=t[2]*k;
  return {q:`The sides of a rectangle are ${a} cm and ${b} cm. Find the length of its diagonal.`,a:c,suf:' cm',dist:[a+b,c+k,c-k,Math.sqrt(a*b)],e:`Diagonal = √(${a}² + ${b}²) = √${a*a+b*b} = ${c} cm.`,v:()=>c*c===a*a+b*b}});
add('cube','Mensuration',1,()=>{const a=ri(2,12);const V=a*a*a;
  return {q:`The volume of a cube is ${V} cm³. Find its total surface area.`,a:6*a*a,suf:' cm²',dist:[4*a*a,6*a*a+a,a*a,12*a],e:`Side = ∛${V} = ${a} cm. Total surface area = 6a² = 6 × ${a*a} = ${6*a*a} cm².`,v:()=>Math.round(Math.cbrt(V))===a}});
/* ---------- Algebra, surds, simplification ---------- */
add('roots','Algebra',2,()=>{const S=ri(3,12),P=ri(1,20);const a=S*S-2*P;
  return {q:`If α and β are the roots of the equation x² − ${S}x + ${P} = 0, find the value of α² + β².`,a,dist:[S*S,a+P,S*S+2*P,S+P],e:`α + β = ${S}, αβ = ${P}. α² + β² = (α + β)² − 2αβ = ${S*S} − ${2*P} = ${a}.`,v:()=>{const d=S*S-4*P;if(d<0)return true;const r1=(S+Math.sqrt(d))/2,r2=(S-Math.sqrt(d))/2;return close(r1*r1+r2*r2,a)}}});
add('xinv','Algebra',2,()=>{const k=ri(3,9);const a=k*k-2,c=k*k*k-3*k;const asked=Math.random()<.5;
  return {q:`If x + 1/x = ${k}, find the value of ${asked?'x² + 1/x²':'x³ + 1/x³'}.`,a:asked?a:c,dist:asked?[k*k,k*k+2,a+k,2*k]:[k*k*k,k*k*k-k,c+k,c-6],e:asked?`Square both sides: x² + 1/x² + 2 = ${k*k}, so x² + 1/x² = ${a}.`:`x³ + 1/x³ = (x + 1/x)³ − 3(x + 1/x) = ${k*k*k} − ${3*k} = ${c}.`,v:()=>{const x=(k+Math.sqrt(k*k-4))/2;return close(asked?x*x+1/(x*x):x*x*x+1/(x*x*x),asked?a:c)}}});
add('surd','Surds and Indices',2,()=>{const a=pick([5,7,11,13]),b=pick([2,3]);const ans=2*(a+b);
  return {q:`Find the value of (√${a} + √${b})² + (√${a} − √${b})².`,a:ans,dist:[ans+2*Math.sqrt(a*b),a+b,ans-2,ans*2],e:`(x + y)² + (x − y)² = 2(x² + y²) = 2(${a} + ${b}) = ${ans}.`,v:()=>close((Math.sqrt(a)+Math.sqrt(b))**2+(Math.sqrt(a)-Math.sqrt(b))**2,ans)}});
add('bodmas','Simplification',1,()=>{const a=ri(10,60),b=ri(2,9),c=ri(2,9),d=ri(2,8)*pick([2,3,4]),e=pick([2,4]);if(d%e)return null;const ans=a+b*c-d/e;
  return {q:`Simplify: ${a} + ${b} × ${c} − ${d} ÷ ${e}`,a:ans,dist:[(a+b)*c-d/e,a+b*c-d*e,a+b*(c-d)/e,ans+e],e:`BODMAS: multiplication and division first: ${b}×${c} = ${b*c}, ${d}÷${e} = ${d/e}. Then ${a} + ${b*c} − ${d/e} = ${ans}.`,v:()=>Function('"use strict";return ('+a+'+'+b+'*'+c+'-'+d+'/'+e+')')()===ans}});
add('ap','Series',2,()=>{const a=ri(2,15),d=ri(2,7),n=ri(8,30);const S=n*(2*a+(n-1)*d)/2;
  return {q:`Find the sum of the first ${n} terms of the series ${a}, ${a+d}, ${a+2*d}, ${a+3*d}, …`,a:S,dist:[S+d,S-n,n*(a+(n-1)*d),S+a],e:`Sum = n/2 [2a + (n − 1)d] = ${n}/2 × [${2*a} + ${n-1} × ${d}] = ${S}.`,v:()=>{let t=0;for(let i=0;i<n;i++)t+=a+i*d;return t===S}}});
add('logchain','Logarithms',2,()=>{const k=ri(3,7);const n=Math.pow(2,k);const chain=[];for(let i=2;i<n&&chain.length<4;i++)chain.push(`log<sub>${i}</sub> ${i+1}`);
  // log2 3 × log3 4 × ... × log_{n-1} n = log2 n  (only list first terms and the last)
  const q=`Find the value of log<sub>2</sub> 3 × log<sub>3</sub> 4 × log<sub>4</sub> 5 × … × log<sub>${n-1}</sub> ${n}.`;
  return {q,a:k,dist:[n,k+1,n-1,k-1<1?k+2:k-1],e:`Each log<sub>a</sub> b = ln b / ln a, so the product telescopes to ln ${n} / ln 2 = log<sub>2</sub> ${n} = ${k}.`,v:()=>{let p=1;for(let i=2;i<n;i++)p*=Math.log(i+1)/Math.log(i);return close(p,k)}}});
add('frac_pct','Simplification',1,()=>{const pairs=[[1,8],[3,8],[5,8],[7,8],[1,16],[3,16],[5,16],[1,12],[5,12],[1,6],[5,6],[2,9],[4,15],[7,20],[3,40]];const [n,d]=pick(pairs);const a=R2(n/d*100);
  return {q:`Express ${n}/${d} as a percentage (correct to two decimal places if needed).`,a,suf:'%',dist:[a+12.5,a/2,R2(d/n),a*2],e:`${n}/${d} × 100 = ${fmt(a)}%.`,v:()=>close(n*100/d,n/d*100,0)||Math.abs(n*100/d-a)<0.006}});
/* ---------- builder ---------- */
const sufs=[];
G.make=(fam,opts)=>{opts=opts||{};for(let tries=0;tries<60;tries++){const o=fam.gen();if(!o||o.skip)continue;
  let ok=false;try{ok=o.v()}catch(e){ok=false}if(!ok)continue;
  const pre=o.pre||'',suf=o.suf||'';const show=x=>typeof x==='string'?x:pre+fmt(x)+suf;
  const canTita=typeof o.a==='number'&&!o.noTita&&Number.isFinite(o.a)&&Math.abs(o.a*100-Math.round(o.a*100))<1e-6&&!(pre||suf.trim()==='%'&&false);
  const tita=opts.forceTita||(opts.allowTita!==false&&canTita&&Math.random()<(opts.titaRate===undefined?0.2:opts.titaRate));
  const item={id:fam.id+'_'+Math.random().toString(36).slice(2,8),fam:fam.id,t:fam.t,d:fam.d,e:o.e};
  if(tita&&canTita){item.ty='num';item.q=o.q+(pre?' (Answer in ₹, enter the number only.)':suf?` (Enter the number only; unit: ${suf.trim()}.)`:' (Enter the numerical answer.)');item.a=fmt(o.a);return item}
  const correct=show(o.a);const set=[correct];(o.dist||[]).forEach(x=>{if(typeof x==='number'&&(!Number.isFinite(x)||x<0&&!(typeof o.a==='number'&&o.a<0)))return;const s=show(x);if(!set.includes(s))set.push(s)});
  let k=1;while(set.length<4&&k<30){if(typeof o.a==='number'){const s=show(o.a+(k%2?k:-k)*Math.max(1,Math.round(Math.abs(o.a)*0.1)));if(!set.includes(s)&&!(o.a>=0&&(o.a+(k%2?k:-k)*Math.max(1,Math.round(Math.abs(o.a)*0.1)))<0))set.push(s)}k++}
  if(set.length<4)continue;const opt=shuffle(set.slice(0,4));item.ty='mcq';item.q=o.q;item.o=opt;item.a=opt.indexOf(correct);return item}
  return null};
G.topics=[...new Set(F.map(f=>f.t))];
G.byTopic=t=>t==='All'?F:F.filter(f=>f.t===t);
G.next=(topic,diff)=>{let pool=G.byTopic(topic||'All');if(diff)pool=pool.filter(f=>diff===1?f.d===1:diff===2?f.d<=2:true);if(!pool.length)pool=F;for(let i=0;i<30;i++){const q=G.make(pick(pool));if(q)return q}return null};
/* exam paper: topic-balanced across families */
G.paper=n=>{const out=[];const fams=shuffle(F);let i=0;const used={};while(out.length<n&&i<fams.length*3){const f=fams[i%fams.length];i++;const key=f.t;if((used[key]||0)>=3&&i<fams.length)continue;const q=G.make(f);if(q){out.push(q);used[key]=(used[key]||0)+1}}return out};
})(window.NG);

window.NG_NUM=window.NG;window.NG=undefined;
