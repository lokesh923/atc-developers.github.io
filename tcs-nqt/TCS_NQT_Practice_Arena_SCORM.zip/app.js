/* Numerical Ability practice: exam mode, unlimited practice, actual-style bank */
window.makePractice=function(PC,NG,BANK,H){
const $=(s,r)=>(r||document).querySelector(s),$$=(s,r)=>[...(r||document).querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const SPEED=H.speed||1;
const L='ABCDEFGH',pass=PC.pass||60;
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const LS={get(k,d){try{const v=localStorage.getItem(PC.prefix+k);return v?JSON.parse(v):d}catch(e){return d}},set(k,v){try{localStorage.setItem(PC.prefix+k,JSON.stringify(v))}catch(e){}}};
const fmt=s=>{s=Math.max(0,Math.round(s));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')};
const eq=(a,b)=>{a=String(a).trim().toLowerCase().replace(/[,₹%\s]/g,'');b=String(b).trim().toLowerCase().replace(/[,₹%\s]/g,'');if(a===b)return true;const re=/^[-+]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?$/;if(re.test(a)&&re.test(b)){const x=parseFloat(a),y=parseFloat(b);return Math.abs(x-y)<=0.011||Math.abs(x-y)<=1e-6*Math.max(1,Math.abs(y))}return false};
const scormReport=(p,sm)=>{if(H.report)H.report(p,sm)};
/* ---------- stats ---------- */
const stats=()=>LS.get('stats',{topics:{},exams:[],att:0,cor:0});
const addStat=(topic,ok,sec)=>{const s=stats();const t=s.topics[topic]=s.topics[topic]||{a:0,c:0,s:0};t.a++;t.s+=sec||0;if(ok)t.c++;s.att++;if(ok)s.cor++;LS.set('stats',s)};
/* ---------- helpers ---------- */
const app=$('#app');let timer=null;
document.addEventListener('click',e=>{if(e.target.tagName==='IMG'&&e.target.closest('.qtext,.rev')){$('#lbimg').src=e.target.src;$('#lightbox').style.display='flex'}});
const bankSeen=()=>LS.get('bank_seen',[]);
const hasImg=q=>/<img/.test(q.q)||(q.o||[]).some(o=>/<img/.test(o));
const pickBank=(n,topic,imgOnly)=>{let pool=BANK.filter(q=>(!topic||topic==='All'||q.t===topic)&&(!imgOnly||hasImg(q)));let seen=bankSeen();let un=pool.filter(q=>!seen.includes(q.id));if(un.length<n){seen=seen.filter(id=>!pool.some(q=>q.id===id));un=pool.filter(q=>!seen.includes(q.id))}const ch=shuffle(un).slice(0,n);LS.set('bank_seen',seen.concat(ch.map(q=>q.id)));return ch.map(q=>q.ty==='mcq'?Object.assign({},q,{ty:'mcq'}):Object.assign({},q,{ty:'num'}))};
const norm=q=>{if(q.ty==='mcq')return q;return Object.assign({},q,{ty:'num'})};
const qBody=(q,i,n)=>{let b=`<div><span class="qno">Question ${i}${n?' of '+n:''}</span><span class="qtopic">${esc(q.t||'')}</span></div><div class="qtext">${q.q}</div>`;return b};
const isCorrect=(q,a)=>a!==undefined&&a!==''&&(q.ty==='mcq'?a===q.a:eq(a,q.a));
const corrText=q=>q.ty==='mcq'?`${L[q.a]}. ${q.o[q.a]}`:esc(q.a);
/* ---------- shell / tabs ---------- */
function shell(tab,inner){app.innerHTML=`<div class="top">${H.home?'<button class="btn sm sec" id="arena">← Arena</button>':''}<span class="brand">TCS NQT · ${PC.title} Practice</span><div class="tabs">${[['exam',`Exam Mode (${PC.n} Q · ${PC.min} min)`],['unl','Unlimited Practice'],['bank','Actual-style Bank'],['prog','My Progress']].map(t=>`<button class="${tab===t[0]?'on':''}" data-t="${t[0]}">${t[1]}</button>`).join('')}</div></div><div class="wrap" id="body">${inner}</div>`;
  if($('#arena'))$('#arena').onclick=()=>{clearInterval(timer);document.onkeydown=null;H.home()};
  $$('.tabs button').forEach(b=>b.onclick=()=>{clearInterval(timer);document.onkeydown=null;go(b.dataset.t)})}
function go(t){({exam:examHome,unl:unlHome,bank:bankHome,prog:progress})[t]()}
/* ---------- EXAM MODE ---------- */
let EX=null;
function examHome(){const s=stats();const last=s.exams.slice(-3).reverse();
  shell('exam',`<div class="card"><span class="tag">EXAM MODE</span><h1>${PC.title}: full test</h1><p class="mut">Same pattern as the live exam. No camera or microphone is needed.</p>
  <table class="t"><tr><th>Questions</th><th>Time</th><th>Marking</th><th>Types</th></tr><tr><td><b>${PC.n}</b></td><td><b>${PC.min} minutes</b> (about ${Math.round(PC.min*60/PC.n)} seconds each)</td><td>1 mark each, <b>no negative marking</b></td><td>MCQ and typed-answer (TITA)</td></tr></table>
  <ul><li>Every paper is new: ${PC.gen} questions are generated fresh from ${NG.F.length} question types and ${PC.n-PC.gen} come from the actual-style bank (image and figure questions). Nothing repeats.</li><li>Move freely between questions, mark for review, change answers. The test submits automatically when the time ends.</li><li>The result shows your score, topic-wise accuracy and an explanation for every question.</li></ul>
  <button class="btn gr" id="start">Start the ${PC.n} question test</button></div>
  ${last.length?`<div class="card"><h2>Your last attempts</h2><table class="t"><tr><th>Date</th><th>Score</th><th>Time used</th></tr>${last.map(e=>`<tr><td>${new Date(e.d).toLocaleString()}</td><td>${e.c}/${PC.n} (${e.p}%)</td><td>${fmt(e.u)}</td></tr>`).join('')}</table></div>`:''}`);
  $('#start').onclick=startExam}
function makePaper(o){o=o||{};const g=o.gen!==undefined?o.gen:PC.gen,bi=o.bimg!==undefined?o.bimg:PC.bimg,ba=o.bany!==undefined?o.bany:PC.bany;const gen=g>0?NG.paper(g):[];const bank=BANK.length?pickBank(bi,'All',true).concat(pickBank(ba,'All')):[];return shuffle(gen.concat(bank)).map(norm)}
function figurePaper(n){return pickBank(n,'All',true).map(norm)}
function startExam(){runPaper(makePaper().slice(0,PC.n),PC.min,{})}
function runPaper(items,minutes,o){o=o||{};EX={items,ans:{},mark:{},vis:{},pos:0,min:minutes,n:items.length,cb:o.cb,label:o.label,end:Date.now()+minutes*60*1000/SPEED,start:Date.now()};examUI()}
function examUI(){const sec=EX;
  app.innerHTML=`<div id="shell2"><div class="top"><span class="brand">${EX.label||(PC.title+' · Exam Mode')}</span><span style="margin-left:auto"></span><div id="timer">${fmt(EX.min*60)}</div></div><div id="mid"><div id="qarea"><div id="qbox"></div></div><div id="side"><div class="pal" id="pal"></div><div class="legend"><i style="background:#0f7d6b"></i>Answered <i style="background:#be123c"></i>Not answered <i style="background:#6d28d9"></i>Marked <i style="background:#fff;border:1px solid #aab"></i>Not visited</div></div></div>
  <div id="foot"><button class="btn sec" id="b_mark">Mark for review &amp; Next</button><button class="btn sec" id="b_clr">Clear response</button><button class="btn sec" id="b_prev">« Previous</button><button class="btn" id="b_save">Save &amp; Next »</button><span class="sp"></span><button class="btn rd" id="b_sub">Submit test</button></div></div>`;
  const st=i=>{const id=i,a=sec.ans[id]!==undefined&&sec.ans[id]!=='',m=sec.mark[id];return m?(a?'markans':'mark'):a?'ans':(sec.vis[id]?'nans':'')};
  const show=()=>{const q=sec.items[sec.pos];sec.vis[sec.pos]=true;const cur=sec.ans[sec.pos];let h=qBody(q,sec.pos+1,sec.items.length);
    if(q.ty==='mcq'){h+=q.o.map((o,k)=>`<div class="opt ${cur===k?'sel':''}" data-o="${k}"><span class="k">${L[k]}.</span><span>${o}</span></div>`).join('')}
    else h+=`<p class="mut sm">Type your answer in the box.</p><input class="ansbox" id="tita" type="text" autocomplete="off" value="${esc(cur||'')}" placeholder="Your answer">`;
    $('#qbox').innerHTML=h;$$('.opt').forEach(d=>d.onclick=()=>{sec.ans[sec.pos]=+d.dataset.o;show()});const ti=$('#tita');if(ti)ti.oninput=()=>{sec.ans[sec.pos]=ti.value;pal()};pal()};
  const pal=()=>{$('#pal').innerHTML=sec.items.map((x,k)=>`<button class="${st(k)} ${k===sec.pos?'cur':''}" data-k="${k}">${k+1}</button>`).join('');$$('#pal button').forEach(b=>b.onclick=()=>{sec.pos=+b.dataset.k;show()})};
  const mv=p=>{sec.pos=Math.max(0,Math.min(sec.items.length-1,p));show()};
  $('#b_mark').onclick=()=>{sec.mark[sec.pos]=true;mv(sec.pos+1)};$('#b_clr').onclick=()=>{delete sec.ans[sec.pos];delete sec.mark[sec.pos];show()};$('#b_prev').onclick=()=>mv(sec.pos-1);$('#b_save').onclick=()=>{delete sec.mark[sec.pos];mv(sec.pos+1)};
  $('#b_sub').onclick=()=>{const a=sec.items.filter((x,k)=>sec.ans[k]!==undefined&&sec.ans[k]!=='').length;const m=document.createElement('div');m.className='modal';m.innerHTML=`<div class="box"><h2>Submit the test?</h2><p>Answered: <b>${a}</b> of ${EX.n} · Not answered: <b>${EX.n-a}</b> · Marked: <b>${Object.keys(sec.mark).length}</b></p><button class="btn rd" id="y">Yes, submit</button> <button class="btn sec" id="n">Go back</button></div>`;document.body.appendChild(m);$('#n',m).onclick=()=>m.remove();$('#y',m).onclick=()=>{m.remove();finishExam()}};
  show();clearInterval(timer);timer=setInterval(()=>{const left=(sec.end-Date.now())/1000;const t=$('#timer');if(t){t.textContent=fmt(left*SPEED);t.className=left*SPEED<=120?'low':''}if(left<=0){clearInterval(timer);finishExam()}},250)}
function finishExam(){clearInterval(timer);const sec=EX;const used=Math.min(EX.min*60,(Date.now()-sec.start)/1000*SPEED);let c=0;const topics={};
  sec.items.forEach((q,k)=>{const ok=isCorrect(q,sec.ans[k]);if(ok)c++;const t=topics[q.t]=topics[q.t]||[0,0];t[1]++;if(ok)t[0]++;addStat(q.t,ok,used/EX.n)});
  const p=Math.round(c/EX.n*100);const s=stats();s.exams.push({d:Date.now(),c,p,u:used});s.exams=s.exams.slice(-30);LS.set('stats',s);
  if(!sec.cb)scormReport(p,PC.tag+':'+c+'/'+EX.n+','+p+'%,att:'+s.att+',acc:'+Math.round(100*s.cor/Math.max(1,s.att))+'%');
  const att=sec.items.filter((x,k)=>sec.ans[k]!==undefined&&sec.ans[k]!=='').length;
  const tl=Object.entries(topics).map(([t,v])=>[t,v[0],v[1],Math.round(100*v[0]/v[1])]).sort((a,b)=>a[3]-b[3]);
  if(sec.cb){sec.cb({c,n:sec.n,p,used,topics:tl,att,items:sec.items,ans:sec.ans});return}
  shell('exam',`<div class="card"><span class="tag">TEST COMPLETED</span><h1>Score: ${c} / ${EX.n} (${p}%)</h1><p><b class="${p>=pass?'ok':'bad'}">${p>=pass?'Good: above the practice target of '+pass+'%':'Below the practice target of '+pass+'%'}</b> · attempted ${att} of ${EX.n} · time used ${fmt(used)}</p>
  <table class="t"><tr><th>Topic</th><th>Correct</th><th>Accuracy</th></tr>${tl.map(t=>`<tr><td>${esc(t[0])}</td><td>${t[1]}/${t[2]}</td><td>${t[3]}%</td></tr>`).join('')}</table>
  <p style="margin-top:12px"><button class="btn gr" id="again">Take a new paper</button> <button class="btn sec" id="prac">Practise weak topics</button></p></div>
  <div class="card"><h2>Answer review</h2>${sec.items.map((q,k)=>{const a=sec.ans[k],ok=isCorrect(q,a);const ya=a===undefined||a===''?'<i>not answered</i>':q.ty==='mcq'?`${L[a]}. ${q.o[a]}`:esc(a);return `<details class="rev"><summary class="${ok?'ok':'bad'}">Q${k+1} · ${ok?'Correct':a===undefined||a===''?'Not answered':'Wrong'} · ${esc(q.t)}</summary><div class="qtext">${q.q}</div><p class="sm"><b>Your answer:</b> ${ya}</p><p class="sm"><b>Correct answer:</b> ${corrText(q)}</p><p class="sm">${q.e||''}</p></details>`}).join('')}</div>`);
  $('#again').onclick=examHome;$('#prac').onclick=()=>{unlHome(tl.length?tl[0][0]:'All')}}
/* ---------- PRACTICE ENGINE (unlimited + bank) ---------- */
function practice(tab,sourceName,getQ,cfg){let cur=null,t0=Date.now(),sess={a:0,c:0,streak:0,best:0,time:0},tm=null,answered=false,sel=null;
  const draw=()=>{cur=getQ();answered=false;sel=null;t0=Date.now();
    if(!cur){$('#pq').innerHTML='<p>No more questions in this selection.</p>';return}
    let h=qBody(cur,sess.a+1,0);if(cur.ty==='mcq')h+=cur.o.map((o,k)=>`<div class="opt" data-o="${k}"><span class="k">${L[k]}.</span><span>${o}</span></div>`).join('');else h+=`<input class="ansbox" id="tita" type="text" autocomplete="off" placeholder="Type your answer and press Enter">`;
    h+=`<div id="fb"></div><div style="margin-top:12px"><button class="btn" id="chk">Check answer</button> <button class="btn sec" id="skip">Skip</button> <span class="mut sm" id="tmr"></span></div>`;$('#pq').innerHTML=h;
    $$('.opt').forEach(d=>d.onclick=()=>{if(answered)return;sel=+d.dataset.o;$$('.opt').forEach(x=>x.classList.toggle('sel',x===d))});
    const ti=$('#tita');if(ti){ti.focus();ti.onkeydown=e=>{if(e.key==='Enter')check()}}
    $('#chk').onclick=check;$('#skip').onclick=()=>{if(!answered)record(false,true);draw()};
    clearInterval(tm);if(cfg.limit){tm=setInterval(()=>{const left=cfg.limit-(Date.now()-t0)/1000*SPEED;const e=$('#tmr');if(e)e.textContent='Time left: '+Math.max(0,Math.round(left))+' s';if(left<=0&&!answered){clearInterval(tm);check(true)}},300)}};
  const record=(ok,skipped)=>{const sec=(Date.now()-t0)/1000*SPEED;sess.a++;if(ok){sess.c++;sess.streak++;sess.best=Math.max(sess.best,sess.streak)}else sess.streak=0;sess.time+=sec;addStat(cur.t,ok,sec);upd()};
  const check=(timeout)=>{if(answered||!cur)return;const a=cur.ty==='mcq'?sel:($('#tita')||{}).value;if((a===null||a===undefined||a==='')&&!timeout){$('#fb').innerHTML='<p class="bad">Choose or type an answer first, or press Skip.</p>';return}
    answered=true;clearInterval(tm);const ok=isCorrect(cur,a);record(ok);
    if(cur.ty==='mcq')$$('.opt').forEach(d=>{const k=+d.dataset.o;if(k===cur.a)d.classList.add('right');else if(k===a)d.classList.add('wrong')});
    $('#fb').innerHTML=`<div class="fb ${ok?'g':'r'}"><b>${ok?'Correct!':timeout&&(a===undefined||a===''||a===null)?'Time is up.':'Not quite.'}</b> Correct answer: <b>${corrText(cur)}</b><br><span class="sm">${cur.e||''}</span></div>`;
    $('#chk').textContent='Next question »';$('#chk').onclick=()=>draw();$('#skip').style.display='none'};
  const upd=()=>{const e=$('#sst');if(e)e.innerHTML=`Attempted <b>${sess.a}</b> · Correct <b>${sess.c}</b> · Accuracy <b>${sess.a?Math.round(100*sess.c/sess.a):0}%</b> · Streak <b>${sess.streak}</b> (best ${sess.best}) · Avg time <b>${sess.a?Math.round(sess.time/sess.a):0}s</b>`};
  document.onkeydown=e=>{if(!cur||e.target.tagName==='INPUT'||e.target.tagName==='SELECT')return;if(e.key==='Enter'){answered?draw():check()}else if(/^[1-4]$/.test(e.key)&&!answered&&cur.ty==='mcq'){sel=+e.key-1;$$('.opt').forEach(x=>x.classList.toggle('sel',+x.dataset.o===sel))}};
  upd();draw()}
/* ---------- UNLIMITED ---------- */
function unlHome(pre){const topics=['All'].concat(NG.topics);
  shell('unl',`<div class="card"><span class="tag">UNLIMITED PRACTICE</span><h1>Endless ${PC.title.toLowerCase()} practice</h1><p class="mut">New questions are generated from ${NG.F.length} question types across ${NG.topics.length} topics, so you can practise as long as you like. Every answer is checked and explained immediately.</p>
  <div class="grid3"><div><label>Topic</label><select id="s_t">${topics.map(t=>`<option ${t===pre?'selected':''}>${t}</option>`).join('')}</select></div><div><label>Level</label><select id="s_d"><option value="0">Mixed</option><option value="1">Easy</option><option value="2">Easy + Medium</option><option value="3">All (hardest included)</option></select></div><div><label>Timer per question</label><select id="s_l"><option value="0">No timer</option><option value="${PC.limit}" selected>${PC.limit} seconds (exam speed)</option><option value="${Math.round(PC.limit*0.6)}">${Math.round(PC.limit*0.6)} seconds (fast)</option><option value="${PC.limit*2}">${PC.limit*2} seconds</option></select></div></div>
  <label style="margin-top:10px"><input type="checkbox" id="s_ti" checked> Include typed-answer (TITA) questions</label><p><button class="btn gr" id="go">Start practice</button></p></div>`);
  $('#go').onclick=()=>{const topic=$('#s_t').value,d=+$('#s_d').value,limit=+$('#s_l').value,ti=$('#s_ti').checked;
    $('#body').innerHTML=`<div class="card" style="padding:10px 16px"><div class="sm" id="sst"></div><div style="margin-top:6px"><button class="btn sm sec" id="chg">Change settings</button></div></div><div class="card" id="pq"></div>`;$('#chg').onclick=()=>{document.onkeydown=null;unlHome(topic)};
    practice('unl','generated',()=>{const q=NG.next(topic,d||0);if(!q)return null;if(!ti&&q.ty==='num')return NG.make(NG.F.find(f=>f.id===q.fam),{allowTita:false})||q;return q},{limit})}}
/* ---------- BANK ---------- */
function bankHome(){const topics=['All'].concat([...new Set(BANK.map(q=>q.t))].sort());
  shell('bank',`<div class="card"><span class="tag">ACTUAL-STYLE BANK</span><h1>${BANK.length} exam-style questions</h1><p class="mut">Image-based and equation questions in the style of the live paper. Unseen questions come first, so you do not see a question again until you have finished the set.</p>
  <div class="grid2"><div><label>Topic</label><select id="b_t">${topics.map(t=>`<option>${esc(t)}</option>`).join('')}</select></div><div><label>Timer per question</label><select id="b_l"><option value="0">No timer</option><option value="${PC.limit}" selected>${PC.limit} seconds</option><option value="${PC.limit*2}">${PC.limit*2} seconds</option></select></div></div>
  <p class="sm mut">Seen so far: <b>${bankSeen().length}</b> of ${BANK.length}. <button class="btn sm sec" id="rs">Reset seen list</button></p><p><button class="btn gr" id="go">Start</button></p></div>`);
  $('#rs').onclick=()=>{LS.set('bank_seen',[]);bankHome()};
  $('#go').onclick=()=>{const topic=$('#b_t').value,limit=+$('#b_l').value;$('#body').innerHTML=`<div class="card" style="padding:10px 16px"><div class="sm" id="sst"></div><div style="margin-top:6px"><button class="btn sm sec" id="chg">Change topic</button></div></div><div class="card" id="pq"></div>`;$('#chg').onclick=()=>{document.onkeydown=null;bankHome()};
    practice('bank','bank',()=>{const r=pickBank(1,topic);return r[0]?norm(r[0]):null},{limit})}}
/* ---------- PROGRESS ---------- */
function progress(){const s=stats();const rows=Object.entries(s.topics).map(([t,v])=>[t,v.a,v.c,Math.round(100*v.c/v.a),Math.round(v.s/v.a)]).sort((a,b)=>a[3]-b[3]);
  shell('prog',`<div class="card"><span class="tag">MY PROGRESS</span><h1>Your ${PC.title.toLowerCase()} practice</h1><p>Total questions attempted: <b>${s.att}</b> · Correct: <b>${s.cor}</b> · Overall accuracy: <b>${s.att?Math.round(100*s.cor/s.att):0}%</b> · Exams taken: <b>${s.exams.length}</b></p>
  ${rows.length?`<table class="t"><tr><th>Topic</th><th>Attempted</th><th>Correct</th><th>Accuracy</th><th>Avg time</th></tr>${rows.map(r=>`<tr><td>${esc(r[0])}</td><td>${r[1]}</td><td>${r[2]}</td><td class="${r[3]>=70?'ok':r[3]<50?'bad':''}">${r[3]}%</td><td>${r[4]} s</td></tr>`).join('')}</table>`:'<p class="mut">Nothing yet. Start a practice session or the exam.</p>'}
  ${s.exams.length?`<h3>Exam scores</h3><table class="t"><tr><th>Date</th><th>Score</th></tr>${s.exams.slice().reverse().map(e=>`<tr><td>${new Date(e.d).toLocaleString()}</td><td>${e.c}/${PC.n} (${e.p}%)</td></tr>`).join('')}</table>`:''}
  <p><button class="btn sm sec" id="clr">Clear my progress</button></p><p class="sm mut">Progress is saved in this browser only.</p></div>`);
  $('#clr').onclick=()=>{if(confirm('Delete all saved progress?')){LS.set('stats',{topics:{},exams:[],att:0,cor:0});progress()}}}
return {home:examHome,unl:unlHome,bank:bankHome,prog:progress,makePaper,runPaper,figurePaper,hasImg,BANK,stats,PC};
};

/* Verbal Ability practice: exam mode, unlimited sentence completion, passage recall, email writing, bank */
window.makeVerbal=function(SG,BK,H){
const $=(s,r)=>(r||document).querySelector(s),$$=(s,r)=>[...(r||document).querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const SPEED=H.speed||1;const L='ABCDEFGH',pass=60;
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const LS={get(k,d){try{const v=localStorage.getItem('vp_'+k);return v?JSON.parse(v):d}catch(e){return d}},set(k,v){try{localStorage.setItem('vp_'+k,JSON.stringify(v))}catch(e){}}};
const fmt=s=>{s=Math.max(0,Math.round(s));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')};
const scormReport=(p,sm)=>{if(H.report)H.report(p,sm)};
/* matching */
const norm=s=>{s=String(s).toLowerCase();s=s.replace(/₹/g,' rs ').replace(/\brs\.?\s*(?=\d)/g,' rs ').replace(/%/g,' percent ').replace(/(\d),(?=\d{3}\b)/g,'$1').replace(/[‐-―-]/g,' ').replace(/[^a-z0-9:.\s]/g,' ').replace(/\.(?=\s|$)/g,' ');return ' '+s.replace(/\s+/g,' ').trim()+' '};
const hasFact=(text,alts)=>{const t=norm(text);return alts.some(a=>{const n=norm(a);if(!n.trim())return false;if(/^[a-z ]+$/.test(n.trim()))return t.includes(n.replace(/ $/,''));return t.includes(n)})};
const numsIn=s=>(norm(s).match(/\b\d[\d.:]*\d\b|\b\d\b/g)||[]);
const scoreRecall=(task,text)=>{const found=[],missing=[];task.facts.forEach(f=>(hasFact(text,f)?found:missing).push(f[0]));const allowed=new Set(numsIn(task.p));task.facts.forEach(f=>f.forEach(a=>numsIn(a).forEach(n=>allowed.add(n))));const wrong=[...new Set(numsIn(text).filter(n=>!allowed.has(n)))];return {found,missing,wrong,pct:Math.round(100*found.length/task.facts.length)}};
const NW={1:'one',2:'two',3:'three',4:'four',5:'five',6:'six',7:'seven',8:'eight',9:'nine',10:'ten',11:'eleven',12:'twelve'};
const scoreEmail=(em,text)=>{const words=text.trim()?text.trim().split(/\s+/).length:0,t=text;const facts=em.facts.map(f=>({f,ok:hasFact(t,/^\d{1,2}$/.test(f)&&NW[+f]?[f,NW[+f]]:[f])}));const fp=facts.length?facts.filter(x=>x.ok).length/facts.length:1;
  const chk=[['Subject line',/subject\s*:/i.test(t)||/^.{4,90}\n\s*\n\s*(dear|hello|hi)\b/i.test(t.trim())],['Formal greeting (Dear …)',/\bdear\s+\w+/i.test(t)],['Purpose stated (I am writing …)',/(i am writing|i write|i would like to|i wish to|this is to|i am pleased|i regret|i apologi[sz]e|i request|please find|following up|thank you for|this is a gentle reminder)/i.test(t)],['Polite request or next step',/(please|kindly|would be grateful|i would appreciate|could you|let me know|look forward)/i.test(t)],['Polite closing',/(thank you|thanks|regards|sincerely|faithfully|yours)/i.test(t)],['Sender name at the end',(()=>{const ls=t.trim().split('\n').filter(x=>x.trim());const l=ls[ls.length-1]||'';return ls.length>3&&l.trim().split(/\s+/).length<=4&&!/[.!?]$/.test(l.trim())})()],['Length 60 to 200 words',words>=60&&words<=200],['Formal tone (no slang)',!/\b(hey|gonna|wanna|asap|u r|pls|plz|lol|bro|dude)\b/i.test(t)]];
  return {facts,chk,words,pct:Math.min(100,Math.round(fp*40+chk.reduce((a,c)=>a+(c[1]?7.5:0),0)))}};
/* stats */
const stats=()=>LS.get('stats',{topics:{},exams:[],att:0,cor:0,rec:[],em:[]});
const addStat=(topic,ok)=>{const s=stats();const t=s.topics[topic]=s.topics[topic]||{a:0,c:0};t.a++;if(ok)t.c++;s.att++;if(ok)s.cor++;LS.set('stats',s)};
const app=$('#app');let timer=null;
document.addEventListener('click',e=>{if(e.target.tagName==='IMG'&&e.target.closest('.qtext')){$('#lbimg').src=e.target.src;$('#lightbox').style.display='flex'}});
const seen=k=>LS.get('seen_'+k,[]);
const pickBank=(k,n)=>{const pool=BK[k]||[];let s=seen(k);let un=pool.filter(q=>!s.includes(q.id));if(un.length<n){s=[];un=pool.slice()}const ch=shuffle(un).slice(0,n);LS.set('seen_'+k,s.concat(ch.map(q=>q.id)));return ch};
function shell(tab,inner){app.innerHTML=`<div class="top">${H.home?'<button class="btn sm sec" id="arena">← Arena</button>':''}<span class="brand">TCS NQT · Verbal Ability Practice</span><div class="tabs">${[['exam','Exam Mode'],['sc','Sentence Completion'],['pr','Passage Recall'],['em','Email Writing'],['bank','Bank'],['prog','My Progress']].map(t=>`<button class="${tab===t[0]?'on':''}" data-t="${t[0]}">${t[1]}</button>`).join('')}</div></div><div class="wrap" id="body">${inner}</div>`;
  if($('#arena'))$('#arena').onclick=()=>{clearInterval(timer);document.onkeydown=null;H.home()};
  $$('.tabs button').forEach(b=>b.onclick=()=>{clearInterval(timer);document.onkeydown=null;go(b.dataset.t)})}
const go=t=>({exam:examHome,sc:scHome,pr:prHome,em:emHome,bank:bankHome,prog:progress})[t]();
const bar=(id,color)=>`<div class="pbar"><i id="${id||'pb'}" style="${color?'background:'+color:''}"></i></div>`;
const runClock=(secs,onEnd)=>{clearInterval(timer);const end=Date.now()+secs*1000/SPEED;const f=()=>{const left=(end-Date.now())/1000*SPEED;const t=$('#timer');if(t){t.textContent=fmt(left)}const pb=$('#pb');if(pb)pb.style.width=Math.max(0,100*left/secs)+'%';if(left<=0){clearInterval(timer);onEnd()}};f();timer=setInterval(f,200)};
/* ============ EXAM MODE ============ */
let EX=null;
function examHome(){const s=stats(),last=s.exams.slice(-3).reverse();
  shell('exam',`<div class="card"><span class="tag">EXAM MODE</span><h1>Verbal Ability: full section</h1><p class="mut">The new Verbal pattern. No camera or microphone is needed.</p>
  <table class="t"><tr><th>Part</th><th>Items</th><th>Time</th></tr><tr><td>Sentence completion</td><td>20</td><td>25 seconds per item (auto-advance, no going back)</td></tr><tr><td>Instruction screen</td><td>1</td><td>25 seconds</td></tr><tr><td>Passage recall</td><td>4</td><td>30 s to read + 90 s to type, per passage</td></tr><tr><td>Instruction screen</td><td>1</td><td>15 seconds</td></tr><tr><td>Email writing</td><td>1</td><td>9 minutes (540 s)</td></tr></table>
  <p>Every attempt is new: sentence completion mixes generated and bank items, passages and the email scenario are generated fresh. Typing: copy and paste are disabled in the answer boxes.</p><button class="btn gr" id="start">Start the Verbal test</button></div>
  ${last.length?`<div class="card"><h2>Last attempts</h2><table class="t"><tr><th>Date</th><th>Overall</th><th>SC</th><th>Recall</th><th>Email</th></tr>${last.map(e=>`<tr><td>${new Date(e.d).toLocaleString()}</td><td>${e.p}%</td><td>${e.sc}/20</td><td>${e.pr}%</td><td>${e.em}%</td></tr>`).join('')}</table></div>`:''}`);
  $('#start').onclick=()=>{EX=newEx();exStep()}}
function newEx(o){o=o||{};const nb=BK.sc.length?(o.bank!==undefined?o.bank:8):0;const gen=SG.paper(20-nb);const bank=nb?pickBank('sc',nb):[];const items=shuffle(gen.concat(bank)).slice(0,20).map(q=>({q,ord:shuffle(q.o.map((_,i)=>i))}));return {sc:items,scAns:{},prs:[SG.passage(),SG.passage(),SG.passage(),SG.passage()],prAns:[],em:SG.email(),emAns:'',phase:'sc',idx:0,sub:'read',cb:o.cb,label:o.label}}
function runVerbal(cb,label){EX=newEx({cb,label,bank:8});exStep()}
function exShell(inner,foot){app.innerHTML=`<div id="shell2"><div class="top"><span class="brand">${EX&&EX.label?EX.label:'Verbal Ability · Exam Mode'}</span><span style="margin-left:auto"></span><div id="timer">0:25</div></div><div id="qarea" style="flex:1;overflow:auto;padding:18px 26px;background:#fff">${inner}</div><div id="foot">${foot||'<span class="sp"></span>'}</div></div>`}
function exStep(){const e=EX;clearInterval(timer);
  if(e.phase==='sc'){const it=e.sc[e.idx];exShell(`<div><span class="qno">Sentence completion ${e.idx+1} of 20</span><span class="qtopic">25 seconds per item</span></div>${bar()}<div class="qtext">${it.q.q}</div>${it.ord.map((oi,k)=>`<div class="opt ${e.scAns[e.idx]===oi?'sel':''}" data-o="${oi}"><span class="k">${L[k]}.</span><span>${it.q.o[oi]}</span></div>`).join('')}`,'<span class="sp"></span><button class="btn" id="nx">Next »</button>');
    $$('.opt').forEach(d=>d.onclick=()=>{e.scAns[e.idx]=+d.dataset.o;$$('.opt').forEach(x=>x.classList.toggle('sel',x===d))});const nx=()=>{clearInterval(timer);e.idx++;if(e.idx>=20){e.phase='ins1';e.idx=0}exStep()};$('#nx').onclick=nx;runClock(25,nx)}
  else if(e.phase==='ins1'){exShell(`<div class="card"><span class="tag">INSTRUCTION SCREEN</span><h2>Passage Recall: how it works</h2><p>You will see 4 short passages, one at a time. Each stays on screen for <b>30 seconds</b> and then disappears. You then have <b>90 seconds</b> to type what you remember: names, numbers, dates, places and the order of events. Write short, clear sentences and do not invent facts.</p></div>${bar()}`,'<span class="sp"></span><button class="btn" id="nx">Continue »</button>');const nx=()=>{clearInterval(timer);e.phase='pr';e.idx=0;e.sub='read';exStep()};$('#nx').onclick=nx;runClock(25,nx)}
  else if(e.phase==='pr'){const p=e.prs[e.idx];
    if(e.sub==='read'){exShell(`<div><span class="qno">Passage recall ${e.idx+1} of 4: READ</span><span class="qtopic">passage disappears in 30 seconds</span></div>${bar()}<p class="qtext" style="user-select:none;line-height:1.8">${esc(p.p)}</p>`,'<span class="sp"></span><span class="mut sm">Read carefully. You cannot skip the reading time.</span>');runClock(30,()=>{e.sub='write';exStep()})}
    else{exShell(`<div><span class="qno">Passage recall ${e.idx+1} of 4: WRITE</span><span class="qtopic">90 seconds</span></div>${bar('pb','#f59e0b')}<p class="mut sm">The passage is hidden. Type everything you remember.</p><textarea class="big" id="ta" spellcheck="false" placeholder="Type here..."></textarea><div class="sm mut" id="wc">0 words</div>`,'<span class="sp"></span><button class="btn" id="nx">Submit &amp; Next »</button>');
      const ta=$('#ta');['paste','copy','cut','drop','contextmenu'].forEach(ev=>ta.addEventListener(ev,x=>x.preventDefault()));ta.oninput=()=>{$('#wc').textContent=(ta.value.trim()?ta.value.trim().split(/\s+/).length:0)+' words'};setTimeout(()=>ta.focus(),50);
      const nx=()=>{clearInterval(timer);e.prAns[e.idx]=ta.value;e.idx++;if(e.idx>=4){e.phase='ins2';e.idx=0}else e.sub='read';exStep()};$('#nx').onclick=nx;runClock(90,nx)}}
  else if(e.phase==='ins2'){exShell(`<div class="card"><span class="tag">INSTRUCTION SCREEN</span><h2>Email Writing: how it works</h2><p>You will get a short work situation. Write a complete, polite email in <b>9 minutes</b>: subject line, greeting, purpose in the first sentence, the facts given, a clear request or next step, a closing and your name.</p></div>${bar()}`,'<span class="sp"></span><button class="btn" id="nx">Continue »</button>');const nx=()=>{clearInterval(timer);e.phase='em';exStep()};$('#nx').onclick=nx;runClock(15,nx)}
  else{exShell(`<div><span class="qno">Email writing</span><span class="qtopic">9 minutes</span></div>${bar('pb','#7c3aed')}<div class="qtext">${esc(e.em.sc)}</div><textarea class="big" id="ta" style="min-height:300px" spellcheck="false" placeholder="Subject: ...&#10;&#10;Dear ...,"></textarea><div class="sm mut" id="wc">0 words</div>`,'<span class="sp"></span><button class="btn rd" id="nx">Submit email &amp; finish</button>');
    const ta=$('#ta');['paste','drop'].forEach(ev=>ta.addEventListener(ev,x=>x.preventDefault()));ta.oninput=()=>{e.emAns=ta.value;$('#wc').textContent=(ta.value.trim()?ta.value.trim().split(/\s+/).length:0)+' words'};const nx=()=>{clearInterval(timer);e.emAns=ta.value;exFinish()};$('#nx').onclick=nx;runClock(540,nx)}}
function exFinish(){const e=EX;let sc_=0;e.sc.forEach((it,k)=>{const ok=e.scAns[k]===it.q.a;if(ok)sc_++;addStat('SC: '+it.q.t,ok)});
  const prs=e.prs.map((p,k)=>({p,text:e.prAns[k]||'',s:scoreRecall(p,e.prAns[k]||'')}));const es=scoreEmail(e.em,e.emAns||'');const prAvg=Math.round(prs.reduce((a,x)=>a+x.s.pct,0)/4);
  const overall=Math.round(100*(sc_+prs.reduce((a,x)=>a+x.s.pct/100,0)+es.pct/100)/25);
  const s=stats();s.exams.push({d:Date.now(),p:overall,sc:sc_,pr:prAvg,em:es.pct});s.exams=s.exams.slice(-30);LS.set('stats',s);if(!e.cb)scormReport(overall,`VERBAL:${overall}%,SC:${sc_}/20,REC:${prAvg}%,EMAIL:${es.pct}%`);
  if(e.cb){e.cb({overall,sc:sc_,prAvg,es:es.pct,prs,esObj:es,e});return}
  shell('exam',`<div class="card"><span class="tag">TEST COMPLETED</span><h1>Verbal score: ${overall}%</h1><table class="t"><tr><th>Part</th><th>Result</th></tr><tr><td>Sentence completion</td><td>${sc_} / 20</td></tr><tr><td>Passage recall (4 tasks)</td><td>${prAvg}% of key facts</td></tr><tr><td>Email writing</td><td>${es.pct}%</td></tr></table><p style="margin-top:10px"><button class="btn gr" id="again">Take a new test</button></p><p class="sm mut">Overall = (sentence completion marks + recall % + email %) out of 25 items. Recall and email scores are practice indicators from key-fact and checklist matching, not official marking.</p></div>
  <div class="card"><h2>Sentence completion review</h2>${e.sc.map((it,k)=>{const a=e.scAns[k],ok=a===it.q.a;return `<details class="rev"><summary class="${ok?'ok':'bad'}">Q${k+1} · ${ok?'Correct':a===undefined?'Not answered':'Wrong'} · ${esc(it.q.t)}</summary><div class="qtext">${it.q.q}</div><p class="sm"><b>Your answer:</b> ${a===undefined?'<i>not answered</i>':it.q.o[a]}</p><p class="sm"><b>Correct:</b> ${it.q.o[it.q.a]}</p><p class="sm">${it.q.e||''}</p></details>`}).join('')}</div>
  <div class="card"><h2>Passage recall review</h2>${prs.map((x,k)=>recallResult(x.p,x.text,x.s,'Passage '+(k+1))).join('')}</div><div class="card"><h2>Email review</h2>${emailResult(e.em,e.emAns,es)}</div>`);
  $('#again').onclick=examHome}
/* ============ shared result renderers ============ */
function recallResult(p,text,s,title){return `<h3>${title}: ${s.pct}% of key facts</h3><div>${s.found.map(f=>`<span class="tc p">✓ ${esc(f)}</span>`).join('')}${s.missing.map(f=>`<span class="tc f">✗ ${esc(f)}</span>`).join('')}</div>${s.wrong.length?`<p class="bad sm">Numbers not in the passage (possible mistakes): ${esc(s.wrong.join(', '))}</p>`:'<p class="ok sm">No invented numbers.</p>'}<details><summary class="sm">Passage, model recall and your answer</summary><p class="sm"><b>Passage:</b> ${esc(p.p)}</p><p class="sm"><b>Model recall:</b> ${esc(p.m)}</p><p class="sm"><b>You wrote:</b> ${esc(text)||'(blank)'}</p></details>`}
function emailResult(em,text,s){return `<h3>${esc(em.title)}: ${s.pct}% (${s.words} words)</h3><div>${s.chk.map(c=>`<span class="tc ${c[1]?'p':'f'}">${c[1]?'✓':'✗'} ${esc(c[0])}</span>`).join('')}</div><p class="sm">Facts from the situation: ${s.facts.map(f=>`<span class="tc ${f.ok?'p':'f'}">${esc(f.f)}</span>`).join('')}</p><details><summary class="sm">Situation, your email and the model email</summary><p class="sm"><b>Situation:</b> ${esc(em.sc)}</p><pre class="samp">${esc(text)||'(blank)'}</pre><pre class="samp">${esc(em.model)}</pre></details>`}
/* ============ SC practice engine ============ */
function scEngine(getQ,limit){let cur=null,t0,tm,answered,sel,sess={a:0,c:0,streak:0,best:0};
  const upd=()=>{const e=$('#sst');if(e)e.innerHTML=`Attempted <b>${sess.a}</b> · Correct <b>${sess.c}</b> · Accuracy <b>${sess.a?Math.round(100*sess.c/sess.a):0}%</b> · Streak <b>${sess.streak}</b> (best ${sess.best})`};
  const draw=()=>{cur=getQ();answered=false;sel=null;t0=Date.now();if(!cur){$('#pq').innerHTML='<p>No more questions.</p>';return}
    const ord=shuffle(cur.o.map((_,i)=>i));cur._ord=ord;$('#pq').innerHTML=`<div><span class="qno">Question ${sess.a+1}</span><span class="qtopic">${esc(cur.t)}</span></div><div class="qtext">${cur.q}</div>${ord.map((oi,k)=>`<div class="opt" data-o="${oi}"><span class="k">${L[k]}.</span><span>${cur.o[oi]}</span></div>`).join('')}<div id="fb"></div><div style="margin-top:12px"><button class="btn" id="chk">Check answer</button> <button class="btn sec" id="skip">Skip</button> <span class="mut sm" id="tmr"></span></div>`;
    $$('.opt').forEach(d=>d.onclick=()=>{if(answered)return;sel=+d.dataset.o;$$('.opt').forEach(x=>x.classList.toggle('sel',x===d))});$('#chk').onclick=()=>check();$('#skip').onclick=()=>{if(!answered){rec(false)}draw()};
    clearInterval(tm);if(limit){tm=setInterval(()=>{const left=limit-(Date.now()-t0)/1000*SPEED;const e=$('#tmr');if(e)e.textContent='Time left: '+Math.max(0,Math.round(left))+' s';if(left<=0&&!answered){clearInterval(tm);check(true)}},300)}};
  const rec=ok=>{sess.a++;if(ok){sess.c++;sess.streak++;sess.best=Math.max(sess.best,sess.streak)}else sess.streak=0;addStat('SC: '+cur.t,ok);upd()};
  const check=timeout=>{if(answered||!cur)return;if(sel===null&&!timeout){$('#fb').innerHTML='<p class="bad">Choose an option first, or press Skip.</p>';return}answered=true;clearInterval(tm);const ok=sel===cur.a;rec(ok);
    $$('.opt').forEach(d=>{const k=+d.dataset.o;if(k===cur.a)d.classList.add('right');else if(k===sel)d.classList.add('wrong')});$('#fb').innerHTML=`<div class="fb ${ok?'g':'r'}"><b>${ok?'Correct!':timeout&&sel===null?'Time is up.':'Not quite.'}</b> Correct answer: <b>${cur.o[cur.a]}</b><br><span class="sm">${cur.e||''}</span></div>`;$('#chk').textContent='Next question »';$('#chk').onclick=()=>draw();$('#skip').style.display='none'};
  document.onkeydown=e=>{if(!cur||e.target.tagName==='SELECT')return;if(e.key==='Enter'){answered?draw():check()}else if(/^[1-4]$/.test(e.key)&&!answered){const d=$$('.opt')[+e.key-1];if(d){sel=+d.dataset.o;$$('.opt').forEach(x=>x.classList.toggle('sel',x===d))}}};
  upd();draw()}
function scHome(){const topics=['All'].concat(SG.topics);
  shell('sc',`<div class="card"><span class="tag">UNLIMITED PRACTICE</span><h1>Sentence completion</h1><p class="mut">Endless grammar and vocabulary items from ${SG.F.length} question types across ${SG.topics.length} topics. Each answer is explained straight away.</p>
  <div class="grid2"><div><label>Topic</label><select id="s_t">${topics.map(t=>`<option>${t}</option>`).join('')}</select></div><div><label>Timer per question</label><select id="s_l"><option value="25" selected>25 seconds (exam speed)</option><option value="0">No timer</option><option value="40">40 seconds</option><option value="15">15 seconds (fast)</option></select></div></div><p><button class="btn gr" id="go">Start</button></p></div>`);
  $('#go').onclick=()=>{const t=$('#s_t').value,l=+$('#s_l').value;$('#body').innerHTML=`<div class="card" style="padding:10px 16px"><div class="sm" id="sst"></div><button class="btn sm sec" id="chg" style="margin-top:6px">Change settings</button></div><div class="card" id="pq"></div>`;$('#chg').onclick=()=>{document.onkeydown=null;scHome()};scEngine(()=>SG.next(t),l)}}
/* ============ PASSAGE RECALL (unlimited / bank) ============ */
function prHome(){shell('pr',`<div class="card"><span class="tag">UNLIMITED PRACTICE</span><h1>Passage recall</h1><p class="mut">A passage is shown, then it disappears and you type what you remember. New passages are generated every time, so you never see the same one twice.</p>
  <div class="grid2"><div><label>Reading time</label><select id="p_r"><option value="30" selected>30 seconds (exam)</option><option value="45">45 seconds (easier)</option><option value="20">20 seconds (harder)</option></select></div><div><label>Writing time</label><select id="p_w"><option value="90" selected>90 seconds (exam)</option><option value="120">120 seconds (easier)</option><option value="60">60 seconds (harder)</option></select></div></div>
  <p class="sm mut">Copy and paste are disabled in the answer box. Your key-fact score is shown after each passage.</p><p><button class="btn gr" id="go">Start</button></p></div>`);
  $('#go').onclick=()=>prLoop(+$('#p_r').value,+$('#p_w').value,()=>SG.passage(),prHome)}
function prLoop(rt,wt,getP,back){const p=getP();const sess=prLoop.s=prLoop.s||{n:0,sum:0};
  const read=()=>{$('#body').innerHTML=`<div class="card"><div class="row2"><span class="tag">READ</span><span class="mut sm">Passage ${sess.n+1} · disappears in ${rt} s</span><span id="tm" class="tmr">${rt}</span></div>${bar('pb')}<p class="qtext" style="user-select:none;line-height:1.8">${esc(p.p)}</p></div>`;runClockMs(rt,'tm',write)};
  const write=()=>{$('#body').innerHTML=`<div class="card"><div class="row2"><span class="tag" style="background:#f59e0b">WRITE</span><span class="mut sm">Passage hidden. Type what you remember.</span><span id="tm" class="tmr">${wt}</span></div>${bar('pb','#f59e0b')}<textarea class="big" id="ta" spellcheck="false" placeholder="Type here..."></textarea><div class="sm mut" id="wc">0 words</div><button class="btn" id="sub" style="margin-top:8px">Submit</button></div>`;const ta=$('#ta');['paste','copy','cut','drop','contextmenu'].forEach(ev=>ta.addEventListener(ev,x=>x.preventDefault()));ta.oninput=()=>{$('#wc').textContent=(ta.value.trim()?ta.value.trim().split(/\s+/).length:0)+' words'};ta.focus();let done=false;const fin=()=>{if(done)return;done=true;clearInterval(timer);result(ta.value)};$('#sub').onclick=fin;runClockMs(wt,'tm',fin)};
  const result=text=>{const s=scoreRecall(p,text);sess.n++;sess.sum+=s.pct;const st=stats();st.rec=(st.rec||[]).concat([s.pct]).slice(-100);LS.set('stats',st);
    $('#body').innerHTML=`<div class="card"><span class="tag">RESULT</span><div class="big">${s.pct}%</div><p class="mut">Session average: <b>${Math.round(sess.sum/sess.n)}%</b> over ${sess.n} passage(s)</p>${recallResult(p,text,s,esc(p.title||'Passage'))}<p style="margin-top:10px"><button class="btn gr" id="nx">Next passage</button> <button class="btn sec" id="bk">Change settings</button></p></div>`;$('#nx').onclick=()=>prLoop(rt,wt,getP,back);$('#bk').onclick=()=>{prLoop.s=null;back()}};
  read()}
const runClockMs=(secs,elId,onEnd)=>{clearInterval(timer);const end=Date.now()+secs*1000/SPEED;const f=()=>{const left=(end-Date.now())/1000*SPEED;const t=$('#'+elId);if(t)t.textContent=Math.max(0,Math.ceil(left));const pb=$('#pb');if(pb)pb.style.width=Math.max(0,100*left/secs)+'%';if(left<=0){clearInterval(timer);onEnd()}};f();timer=setInterval(f,200)};
/* ============ EMAIL (unlimited / bank) ============ */
function emHome(){shell('em',`<div class="card"><span class="tag">UNLIMITED PRACTICE</span><h1>Email writing</h1><p class="mut">A new work situation every time (leave, complaint, follow-up, request, apology, application, reminder, thanks). Write the email, then see your checklist score and a model email.</p>
  <div class="grid2"><div><label>Time limit</label><select id="e_t"><option value="540" selected>9 minutes (exam)</option><option value="0">No timer</option><option value="360">6 minutes (harder)</option></select></div><div></div></div><p><button class="btn gr" id="go">Start</button></p></div>`);
  $('#go').onclick=()=>emLoop(+$('#e_t').value,()=>SG.email(),emHome)}
function emLoop(limit,getE,back){const em=getE();$('#body').innerHTML=`<div class="card"><div class="row2"><span class="tag">EMAIL</span><span class="mut sm">${limit?'Time limit '+limit/60+' min':'No time limit'}</span><span id="tm" class="tmr">${limit?fmt(limit):'∞'}</span></div>${limit?bar('pb','#7c3aed'):''}<div class="qtext">${esc(em.sc)}</div><textarea class="big" id="ta" style="min-height:300px" spellcheck="false" placeholder="Subject: ...&#10;&#10;Dear ...,"></textarea><div class="sm mut" id="wc">0 words</div><button class="btn" id="sub" style="margin-top:8px">Submit email</button></div>`;
  const ta=$('#ta');['paste','drop'].forEach(ev=>ta.addEventListener(ev,x=>x.preventDefault()));ta.oninput=()=>{$('#wc').textContent=(ta.value.trim()?ta.value.trim().split(/\s+/).length:0)+' words'};ta.focus();let done=false;
  const fin=()=>{if(done)return;done=true;clearInterval(timer);const s=scoreEmail(em,ta.value);const st=stats();st.em=(st.em||[]).concat([s.pct]).slice(-100);LS.set('stats',st);
    $('#body').innerHTML=`<div class="card"><span class="tag">RESULT</span><div class="big">${s.pct}%</div>${emailResult(em,ta.value,s)}<p class="sm mut">Practice score from checklist and fact matching, not official marking.</p><p><button class="btn gr" id="nx">Next situation</button> <button class="btn sec" id="bk">Change settings</button></p></div>`;$('#nx').onclick=()=>emLoop(limit,getE,back);$('#bk').onclick=back};
  $('#sub').onclick=fin;if(limit)runClockMs2(limit,fin)}
const runClockMs2=(secs,onEnd)=>{clearInterval(timer);const end=Date.now()+secs*1000/SPEED;const f=()=>{const left=(end-Date.now())/1000*SPEED;const t=$('#tm');if(t)t.textContent=fmt(left);const pb=$('#pb');if(pb)pb.style.width=Math.max(0,100*left/secs)+'%';if(left<=0){clearInterval(timer);onEnd()}};f();timer=setInterval(f,200)};
/* ============ BANK ============ */
function bankHome(){shell('bank',`<div class="card"><span class="tag">BANK</span><h1>Hand-written exam-style bank</h1><p class="mut">${BK.sc.length} sentence-completion items, ${BK.pr.length} passages and ${BK.em.length} email tasks. Unseen items come first.</p>
  <p><button class="btn gr" id="b1">Sentence completion bank (${BK.sc.length})</button> <button class="btn gr" id="b2">Passage bank (${BK.pr.length})</button> <button class="btn gr" id="b3">Email bank (${BK.em.length})</button></p><p class="sm mut"><button class="btn sm sec" id="rs">Reset seen lists</button></p></div>`);
  $('#rs').onclick=()=>{['sc','pr','em'].forEach(k=>LS.set('seen_'+k,[]));bankHome()};
  $('#b1').onclick=()=>{$('#body').innerHTML=`<div class="card" style="padding:10px 16px"><div class="sm" id="sst"></div><button class="btn sm sec" id="chg" style="margin-top:6px">Back</button></div><div class="card" id="pq"></div>`;$('#chg').onclick=()=>{document.onkeydown=null;bankHome()};scEngine(()=>{const r=pickBank('sc',1)[0];return r?Object.assign({},r):null},25)};
  $('#b2').onclick=()=>prLoop(30,90,()=>pickBank('pr',1)[0],bankHome);$('#b3').onclick=()=>emLoop(540,()=>pickBank('em',1)[0],bankHome)}
/* ============ PROGRESS ============ */
function progress(){const s=stats();const rows=Object.entries(s.topics).map(([t,v])=>[t,v.a,v.c,Math.round(100*v.c/v.a)]).sort((a,b)=>a[3]-b[3]);const avg=a=>a&&a.length?Math.round(a.reduce((x,y)=>x+y,0)/a.length):0;
  shell('prog',`<div class="card"><span class="tag">MY PROGRESS</span><h1>Your verbal practice</h1><p>Sentence-completion attempted: <b>${s.att}</b> · Correct: <b>${s.cor}</b> · Accuracy: <b>${s.att?Math.round(100*s.cor/s.att):0}%</b> · Passages recalled: <b>${(s.rec||[]).length}</b> (average ${avg(s.rec)}%) · Emails written: <b>${(s.em||[]).length}</b> (average ${avg(s.em)}%) · Full tests: <b>${s.exams.length}</b></p>
  ${rows.length?`<table class="t"><tr><th>Topic</th><th>Attempted</th><th>Correct</th><th>Accuracy</th></tr>${rows.map(r=>`<tr><td>${esc(r[0])}</td><td>${r[1]}</td><td>${r[2]}</td><td class="${r[3]>=70?'ok':r[3]<50?'bad':''}">${r[3]}%</td></tr>`).join('')}</table>`:'<p class="mut">Nothing yet.</p>'}
  <p><button class="btn sm sec" id="clr">Clear my progress</button></p><p class="sm mut">Saved in this browser only.</p></div>`);$('#clr').onclick=()=>{if(confirm('Delete all saved progress?')){LS.set('stats',{topics:{},exams:[],att:0,cor:0,rec:[],em:[]});progress()}}}
return {home:examHome,sc:scHome,pr:prHome,em:emHome,bank:bankHome,prog:progress,runVerbal,recallResult,emailResult,stats,newEx};
};

/* Advanced coding: problem list, editor, online compiler (Judge0 + Piston fallback), 90-minute mock section */
window.makeCoding=function(PROBS,H){
const $=(s,r)=>(r||document).querySelector(s),$$=(s,r)=>[...(r||document).querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const SPEED=H.speed||1,app=()=>$('#app');
const LS={get(k,d){try{const v=localStorage.getItem('cd_'+k);return v?JSON.parse(v):d}catch(e){return d}},set(k,v){try{localStorage.setItem('cd_'+k,JSON.stringify(v))}catch(e){}}};
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const fmt=s=>{s=Math.max(0,Math.round(s));const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return (h?h+':':'')+String(m).padStart(h?2:1,'0')+':'+String(s%60).padStart(2,'0')};
const TPL={c:'#include <stdio.h>\n\nint main(void) {\n    /* read the input with scanf and print the answer with printf */\n    \n    return 0;\n}\n',
cpp:'#include <bits/stdc++.h>\nusing namespace std;\n\nint main() {\n    ios::sync_with_stdio(false);\n    cin.tie(nullptr);\n    // read the input with cin and print the answer with cout\n    \n    return 0;\n}\n',
java:'import java.util.*;\nimport java.io.*;\n\npublic class Main {\n    public static void main(String[] args) throws IOException {\n        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));\n        // read the input and print the answer\n        \n    }\n}\n',
python:'import sys\n\ndef main():\n    data = sys.stdin.read().split()\n    # read the input from data and print the answer\n    \n\nmain()\n'};
const LN={c:'C (GCC)',cpp:'C++ (GCC)',java:'Java',python:'Python 3'};
/* ---------- compiler layer ---------- */
const CF=H.compiler||{backends:[{type:'judge0',url:'https://ce.judge0.com',headers:{},langs:{c:50,cpp:54,java:62,python:71},cpuSec:5,memKB:256000},{type:'piston',url:'https://emkc.org/api/v2/piston',langs:{c:'c',cpp:'c++',java:'java',python:'python'}}]};
const b64=s=>btoa(unescape(encodeURIComponent(s)));const unb=s=>{try{return s?decodeURIComponent(escape(atob(s))):''}catch(e){try{return atob(s)}catch(_){return ''}}};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let good=0;const bad={};
async function http(url,opt,tries){tries=tries||4;let last;for(let k=0;k<tries;k++){try{const ctl=new AbortController();const to=setTimeout(()=>ctl.abort(),45000);const r=await fetch(url,Object.assign({signal:ctl.signal},opt));clearTimeout(to);if(r.status===429||r.status===503||r.status===502||r.status===504){last=new Error('busy '+r.status);await sleep(1200*(k+1));continue}if(!r.ok){const t=await r.text();throw new Error('HTTP '+r.status+': '+t.slice(0,120))}return await r.json()}catch(e){last=e;if(/HTTP 4/.test(e.message))throw e;await sleep(800*(k+1))}}throw last||new Error('network')}
async function runJudge0(b,lang,code,stdin){const body={source_code:b64(code),language_id:b.langs[lang],stdin:b64(stdin||''),cpu_time_limit:b.cpuSec||5,memory_limit:b.memKB||256000};
  const h=Object.assign({'Content-Type':'application/json'},b.headers||{});let r=null;
  if(!b.nowait){try{r=await http(b.url+'/submissions?base64_encoded=true&wait=true',{method:'POST',headers:h,body:JSON.stringify(body)})}catch(e){if(/HTTP 4/.test(e.message)&&/wait/i.test(e.message))b.nowait=true;else throw e}}
  if(!r)r=await http(b.url+'/submissions?base64_encoded=true',{method:'POST',headers:h,body:JSON.stringify(body)});
  if(!r.status||r.status.id<3){const tok=r.token;for(let k=0;k<30&&(!r.status||r.status.id<3);k++){await sleep(k<3?500:900);r=await http(b.url+'/submissions/'+tok+'?base64_encoded=true',{headers:h});r.token=tok}}
  return {status:r.status?r.status.id:0,desc:r.status?r.status.description:'',out:unb(r.stdout),err:unb(r.stderr),comp:unb(r.compile_output),time:r.time,mem:r.memory}}
async function runPiston(b,lang,code,stdin){const name=lang==='java'?'Main.java':lang==='python'?'main.py':lang==='c'?'main.c':'main.cpp';
  const r=await http(b.url+'/execute',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({language:b.langs[lang],version:'*',files:[{name,content:code}],stdin:stdin||'',compile_timeout:15000,run_timeout:5000})});
  const c=r.compile,u=r.run||{};if(c&&c.code!==0&&c.code!==undefined)return {status:6,desc:'Compilation Error',out:'',err:'',comp:(c.stderr||c.output||'')};
  if(u.signal==='SIGKILL'&&!u.stdout)return {status:5,desc:'Time Limit Exceeded',out:u.stdout||'',err:u.stderr||'',comp:''};
  if(u.code!==0&&u.code!==undefined&&u.code!==null)return {status:11,desc:'Runtime Error',out:u.stdout||'',err:u.stderr||'',comp:''};
  return {status:3,desc:'Accepted',out:u.stdout||'',err:u.stderr||'',comp:''}}
async function runCode(lang,code,stdin){const order=CF.backends.map((b,i)=>i);order.sort((a,b2)=>(a===good?-1:0)-(b2===good?-1:0));let lastErr;
  for(const i of order){const b=CF.backends[i];if(bad[i]&&Date.now()-bad[i]<30000)continue;try{const r=b.type==='piston'?await runPiston(b,lang,code,stdin):await runJudge0(b,lang,code,stdin);good=i;delete bad[i];return r}catch(e){lastErr=e;if(/HTTP 4/.test(e.message)&&b.type==='judge0'&&!/429/.test(e.message)){/* auth / bad request: try next */}bad[i]=Date.now()}}
  throw new Error('The compiler service could not be reached ('+(lastErr&&lastErr.message||'network error')+'). Check your internet connection and try again.')}
async function ping(){const out=[];for(const b of CF.backends){try{await http(b.url+(b.type==='piston'?'/runtimes':'/languages'),{headers:b.headers||{}},1);out.push(b.type);}catch(e){}}return out}
const same=(a,b)=>String(a).trim().split(/\s+/).join(' ')===String(b).trim().split(/\s+/).join(' ');
const verdict=(r,exp)=>r.status===6?'CE':r.status===5?'TLE':(r.status>=7&&r.status<=12)?'RE':r.status!==3?'ERR':same(r.out,exp)?'AC':'WA';
const NAMES={AC:'Passed',WA:'Wrong answer',TLE:'Time limit exceeded',RE:'Runtime error',CE:'Compilation error',ERR:'Service error'};
/* ---------- editor view (shared by practice and mock) ---------- */
function editorView(root,p,st,opt){opt=opt||{};
  const key=()=>p.id+'_'+st.lang,get=()=>st.code[key()]!==undefined?st.code[key()]:TPL[st.lang];
  root.innerHTML=`<div class="cwrap"><div class="cl"><h2>${esc(p.title)} <span class="lv ${p.level}">${p.level}</span></h2><p class="sm mut">${esc(p.topic)}</p><p>${p.desc}</p><h3>Input format</h3><p>${p.infmt}</p><h3>Output format</h3><p>${p.outfmt}</p><h3>Constraints</h3><p>${p.cons}</p>${p.samples.map((s,k)=>`<h3>Sample ${k+1}</h3><div class="samp"><b>Input</b>\n${esc(s.i)}</div><div class="samp"><b>Output</b>\n${esc(s.o)}</div>`).join('')}</div>
  <div class="cr"><div style="display:flex;gap:8px;align-items:center;margin-bottom:6px;flex-wrap:wrap"><select id="lang" style="width:auto">${Object.keys(LN).map(k=>`<option value="${k}" ${k===st.lang?'selected':''}>${LN[k]}</option>`).join('')}</select><button class="btn sm sec" id="rst">Reset code</button><span style="flex:1"></span><button class="btn sm sec" id="run">▶ Run</button><button class="btn sm gr" id="sub">Submit</button></div>
  <div class="edwrap"><div class="gut" id="gut">1</div><textarea class="ed" id="ed" spellcheck="false" autocapitalize="off" autocomplete="off"></textarea></div><label>Custom input for Run</label><textarea id="cin" class="ed cin" spellcheck="false"></textarea><div class="out" id="out">${opt.prev?resHTML(opt.prev):'Output will appear here.'}</div></div></div>`;
  const ed=$('#ed',root);ed.value=get();$('#cin',root).value=p.samples[0].i;
  const gut=()=>{const n=ed.value.split('\n').length;$('#gut',root).textContent=Array.from({length:n},(_,k)=>k+1).join('\n')};gut();
  ed.oninput=()=>{st.code[key()]=ed.value;gut();opt.save&&opt.save()};ed.onscroll=()=>{$('#gut',root).scrollTop=ed.scrollTop};
  ed.onkeydown=e=>{if(e.key==='Tab'){e.preventDefault();const s=ed.selectionStart;ed.value=ed.value.slice(0,s)+'    '+ed.value.slice(ed.selectionEnd);ed.selectionStart=ed.selectionEnd=s+4;ed.oninput()}};
  $('#lang',root).onchange=e=>{st.lang=e.target.value;opt.save&&opt.save();editorView(root,p,st,opt)};
  $('#rst',root).onclick=()=>{if(confirm('Reset to the starter code?')){delete st.code[key()];opt.save&&opt.save();editorView(root,p,st,opt)}};
  const fmtRun=r=>{let s='Status: '+r.desc+(r.time?'   Time: '+r.time+'s':'')+'\n';if(r.comp)s+='\n[Compiler]\n'+r.comp;if(r.err)s+='\n[stderr]\n'+r.err;return s+'\n[Output]\n'+(r.out||'(empty)')};
  $('#run',root).onclick=async()=>{const o=$('#out',root);o.textContent='Running…';$('#run',root).disabled=true;try{const r=await runCode(st.lang,ed.value,$('#cin',root).value);o.textContent=fmtRun(r)}catch(e){o.textContent=e.message}$('#run',root).disabled=false};
  $('#sub',root).onclick=async()=>{const o=$('#out',root);$('#sub',root).disabled=true;$('#run',root).disabled=true;const tot=p.tests.length,vs=new Array(tot);let done=0,pass=0,nxt=0;o.textContent='Running test cases 0/'+tot+'…';
    try{const worker=async()=>{while(nxt<tot){const t=nxt++;try{const r=await runCode(st.lang,ed.value,p.tests[t].i);const v=verdict(r,p.tests[t].o);vs[t]={v,time:r.time,msg:v==='CE'?r.comp:v==='RE'?(r.err||r.desc):''};if(t<2&&v!=='AC'&&v!=='CE'){vs[t].inp=p.tests[t].i;vs[t].exp=p.tests[t].o;vs[t].got=r.out}if(v==='AC')pass++}catch(e){vs[t]={v:'ERR',msg:e.message}}done++;o.textContent='Running test cases '+done+'/'+tot+'…'}};
      await Promise.all([worker(),worker(),worker()]);const res={passed:pass,total:tot,vs,lang:st.lang,at:Date.now()};o.innerHTML=resHTML(res);opt.onSubmit&&opt.onSubmit(res)}catch(e){o.textContent=e.message}
    $('#sub',root).disabled=false;$('#run',root).disabled=false}}
function resHTML(r){const first=r.vs.find(v=>v&&(v.v==='CE'||v.v==='RE'));const w=r.vs.find(v=>v&&v.inp&&v.v==='WA');
  return `<b>${r.passed} of ${r.total} test cases passed</b> (${LN[r.lang]||''})<br>${r.vs.map((v,k)=>`<span class="tc ${v&&v.v==='AC'?'p':v&&(v.v==='TLE'||v.v==='ERR')?'o':'f'}" title="${v?NAMES[v.v]:''}">#${k+1} ${v?NAMES[v.v]:''}</span>`).join('')}${first&&first.msg?'<br><pre style="white-space:pre-wrap;margin:6px 0 0">'+esc(first.msg.slice(0,700))+'</pre>':''}${w?`<br><b>First failing sample</b><pre style="white-space:pre-wrap;margin:4px 0">Input:\n${esc(w.inp)}\nExpected:\n${esc(w.exp)}\nYour output:\n${esc(w.got||'(empty)')}</pre>`:''}`}
/* ---------- shell ---------- */
function shell(inner,o){o=o||{};app().innerHTML=`<div id="shell2"><div class="top">${H.home?'<button class="btn sm sec" id="arena">← Arena</button>':''}<span class="brand">${esc(o.title||'TCS NQT · Advanced Coding Practice')}</span><span style="margin-left:auto"></span>${o.timer?'<div id="timer">--:--</div>':''}</div><div id="qarea" style="flex:1;overflow:auto;padding:16px 22px">${inner}</div>${o.foot?`<div id="foot">${o.foot}</div>`:''}</div>`;
  if($('#arena'))$('#arena').onclick=()=>{if(o.confirmLeave&&!confirm('Leave this section? Your progress in this section will be lost.'))return;clearInterval(timer);H.home()}}
let timer=null;
/* ---------- practice ---------- */
function home(){clearInterval(timer);const R=LS.get('res',{});const levels=['All','Medium','Hard'],topics=['All',...new Set(PROBS.map(p=>p.topic))];
  shell(`<div class="wrap"><div class="card"><span class="tag">ADVANCED CODING PRACTICE</span><h1>${PROBS.length} coding problems</h1><p class="mut">Write the solution in C, C++, Java or Python. Read from standard input and print to standard output. <b>Run</b> tests your code on your own input; <b>Submit</b> runs every hidden test case.</p>
  <div class="grid3"><div><label>Level</label><select id="f_l">${levels.map(l=>`<option>${l}</option>`).join('')}</select></div><div><label>Topic</label><select id="f_t">${topics.map(l=>`<option>${esc(l)}</option>`).join('')}</select></div><div><label>Show</label><select id="f_s"><option>All</option><option>Not solved</option><option>Solved</option></select></div></div></div><div id="plist" class="pgrid"></div></div>`);
  const draw=()=>{const l=$('#f_l').value,t=$('#f_t').value,s=$('#f_s').value;const list=PROBS.filter(p=>(l==='All'||p.level===l)&&(t==='All'||p.topic===t)&&(s==='All'||(s==='Solved'?R[p.id]&&R[p.id].passed===R[p.id].total:!(R[p.id]&&R[p.id].passed===R[p.id].total))));
    $('#plist').innerHTML=list.map(p=>{const r=R[p.id];const ok=r&&r.passed===r.total;return `<div class="pcard"><div><span class="lv ${p.level}">${p.level}</span> <span class="sm mut">${esc(p.topic)}</span></div><h3 style="margin:6px 0">${esc(p.title)}</h3><p class="sm mut">${r?`Best: ${r.passed}/${r.total} test cases ${ok?'<b class="ok">✓ solved</b>':''}`:'Not attempted'}</p><button class="btn sm" data-id="${p.id}">${r?'Open again':'Solve'}</button></div>`}).join('')||'<p class="mut">No problems match.</p>';
    $$('#plist button').forEach(b=>b.onclick=()=>open(b.dataset.id))};
  ['f_l','f_t','f_s'].forEach(id=>$('#'+id).onchange=draw);draw()}
function open(id){const p=PROBS.find(x=>x.id===id);const st=LS.get('st_'+id,null)||{lang:'python',code:{}};const R=LS.get('res',{});
  shell('<div id="ev"></div>',{title:'Coding · '+p.title,foot:'<button class="btn sec" id="back">« All problems</button>'});$('#back').onclick=home;
  editorView($('#ev'),p,st,{prev:R[id],save:()=>LS.set('st_'+id,st),onSubmit:res=>{const r=LS.get('res',{});if(!r[id]||res.passed>=r[id].passed){r[id]={passed:res.passed,total:res.total,lang:res.lang,at:res.at};LS.set('res',r)}}})}
/* ---------- mock section ---------- */
function pickMock(){const seen=LS.get('mock_seen',[]);const take=(lv)=>{let pool=PROBS.filter(p=>p.level===lv&&!seen.includes(p.id));if(!pool.length){pool=PROBS.filter(p=>p.level===lv);for(const p of pool){const i=seen.indexOf(p.id);if(i>=0)seen.splice(i,1)}}return pool[Math.floor(Math.random()*pool.length)]};const a=take('Medium'),b=take('Hard');LS.set('mock_seen',seen.concat([a.id,b.id]));return [a,b]}
function runMock(cb,label,minutes){const probs=pickMock();minutes=minutes||90;const sts=probs.map(()=>({lang:'python',code:{}}));const res={};let pi=0;let finished=false;const end=Date.now()+minutes*60*1000/SPEED;
  shell(`<div class="ctabs" id="ct"></div><div id="ev"></div>`,{title:label||'Advanced Coding · Mock section',timer:true,confirmLeave:true,foot:'<span class="sm mut">Run tests your code on your own input. Submit runs all hidden test cases. Your best submission counts.</span><span style="flex:1"></span><button class="btn rd" id="fin">Submit section</button>'});
  const draw=()=>{$('#ct').innerHTML=probs.map((p,k)=>`<button class="${k===pi?'on':''}" data-k="${k}">Problem ${k+1}${res[p.id]?' ✓':''}</button>`).join('');$$('#ct button').forEach(b=>b.onclick=()=>{pi=+b.dataset.k;draw()});
    const p=probs[pi];editorView($('#ev'),p,sts[pi],{prev:res[p.id],onSubmit:r=>{if(!res[p.id]||r.passed>=res[p.id].passed)res[p.id]=r;const t=$$('#ct button')[pi];if(t&&!/✓/.test(t.textContent))t.textContent+=' ✓'}})};
  const done=()=>{if(finished)return;finished=true;clearInterval(timer);const per=probs.map(p=>({p,r:res[p.id]||null,pct:res[p.id]?Math.round(100*res[p.id].passed/res[p.id].total):0}));cb({per,pct:Math.round(per.reduce((a,x)=>a+x.pct,0)/per.length),used:Math.min(minutes*60,(minutes*60*1000/SPEED-(end-Date.now()))/1000*SPEED)})};
  $('#fin').onclick=()=>{const m=document.createElement('div');m.className='modal';m.innerHTML='<div class="box"><h2>Submit this section?</h2><p>Make sure you pressed <b>Submit</b> on each problem to run all test cases. You cannot return to this section.</p><button class="btn rd" id="y">Yes, submit section</button> <button class="btn sec" id="n">Go back</button></div>';document.body.appendChild(m);$('#n',m).onclick=()=>m.remove();$('#y',m).onclick=()=>{m.remove();done()}};
  draw();clearInterval(timer);timer=setInterval(()=>{const left=(end-Date.now())/1000*SPEED;const t=$('#timer');if(t){t.textContent=fmt(left);t.className=left<=300?'low':''}if(left<=0){clearInterval(timer);done()}},250)}
return {home,runMock,runCode,ping,PROBS,LS,resHTML};
};

/* TCS NQT Practice Arena: landing page, browser check, auto-built full mocks, figure tests, section practice */
(function(){
const D=window.ARENA_DATA,CFG=window.ARENA_CFG;
const $=(s,r)=>(r||document).querySelector(s),$$=(s,r)=>[...(r||document).querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const SPEED=Math.max(1,parseFloat((location.search.match(/[?&]speed=([\d.]+)/)||[])[1])||CFG.speed||1);
const LSg=(k,d)=>{try{const v=localStorage.getItem('arena_'+k);return v?JSON.parse(v):d}catch(e){return d}},LSs=(k,v)=>{try{localStorage.setItem('arena_'+k,JSON.stringify(v))}catch(e){}};
const fmt=s=>{s=Math.max(0,Math.round(s));const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return (h?h+'h ':'')+m+'m'};
const L='ABCDEFGH';
document.addEventListener('click',e=>{if(e.target.tagName==='IMG'&&e.target.closest('.qtext,.rev')){$('#lbimg').src=e.target.src;$('#lightbox').style.display='flex'}});
/* ---------- SCORM 1.2 ---------- */
let lms=null,t0=Date.now(),MOCKDONE=false;const findAPI=w=>{let n=0;while(w&&!w.API&&w.parent&&w.parent!==w&&n<20){w=w.parent;n++}return w&&w.API?w.API:null};
const sc=(f,a,b)=>{try{return lms?(b===undefined?(a===undefined?lms[f]():lms[f](a)):lms[f](a,b)):''}catch(e){return ''}};
const tf=s=>{s=Math.round(s);return String(Math.floor(s/3600)).padStart(4,'0')+':'+String(Math.floor(s%3600/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')};
const scormInit=()=>{try{lms=findAPI(window);if(!lms&&window.opener)lms=findAPI(window.opener)}catch(e){}if(!lms)return;sc('LMSInitialize','');const st=sc('LMSGetValue','cmi.core.lesson_status');if(!st||st==='not attempted')sc('LMSSetValue','cmi.core.lesson_status','incomplete');sc('LMSCommit','')};
const scormReport=(pct,sum)=>{if(!lms)return;sc('LMSSetValue','cmi.core.score.min','0');sc('LMSSetValue','cmi.core.score.max','100');sc('LMSSetValue','cmi.core.score.raw',String(Math.round(pct)));sc('LMSSetValue','cmi.core.lesson_status',pct>=CFG.passMark?'passed':'failed');sc('LMSSetValue','cmi.core.session_time',tf((Date.now()-t0)/1000));sc('LMSSetValue','cmi.suspend_data',String(sum).slice(0,3800));sc('LMSCommit','')};
window.addEventListener('beforeunload',()=>{if(lms){sc('LMSSetValue','cmi.core.session_time',tf((Date.now()-t0)/1000));sc('LMSCommit','');sc('LMSFinish','');lms=null}});
/* ---------- modules ---------- */
const H={home:()=>home(),speed:SPEED,report:(p,s)=>{if(!MOCKDONE)scormReport(p,s)},compiler:CFG.compiler};
const P={
 NUM:makePractice({title:'Numerical Ability',n:20,min:25,gen:14,bimg:4,bany:2,limit:75,prefix:'np_',tag:'NUM',pass:60},window.NG_NUM,D.S1,H),
 REA:makePractice({title:'Reasoning Ability',n:20,min:25,gen:14,bimg:4,bany:2,limit:75,prefix:'rp_',tag:'REAS',pass:60},window.NG_REA,D.S2,H),
 ADV:makePractice({title:'Advanced Quant + Reasoning',n:14,min:25,gen:10,bimg:3,bany:1,limit:107,prefix:'ap_',tag:'ADV',pass:60},window.NG_ADV,D.S4,H),
 VER:makeVerbal(window.SG,D.V,H),
 COD:makeCoding(D.S5,H)};
const SEC={NUM:{name:'Numerical Ability',q:'20 Q',min:25,short:'Numerical'},REA:{name:'Reasoning Ability',q:'20 Q',min:25,short:'Reasoning'},VER:{name:'Verbal Ability',q:'25 tasks',min:26,short:'Verbal'},ADV:{name:'Advanced Quant + Reasoning',q:'14 Q',min:25,short:'Adv. Quant + Reasoning'},COD:{name:'Advanced Coding',q:'2 Q',min:90,short:'Advanced Coding'}};
const MOCKS=[
 {id:'full',title:'Full Mock (auto-built)',sections:['NUM','REA','VER','ADV','COD'],desc:'The complete test in order: five sections, each with its own timer, answers final once a section is submitted. A new paper is built every time from the generated questions and the unseen part of the bank.'},
 {id:'found',title:'Foundation Mock (auto-built)',sections:['NUM','REA','VER'],desc:'The first three sections: Numerical, Reasoning and the new-pattern Verbal (sentence completion, passage recall, email). A good daily mock.'},
 {id:'adv',title:'Advanced Mock (auto-built)',sections:['ADV','COD'],desc:'Advanced Quant + Reasoning followed by the 90-minute coding section with the online compiler (C, C++, Java, Python).'},
 {id:'img',title:'Master Mock (image-based)',sections:['NUM','REA','ADV'],img:true,desc:'Figure-heavy and equation-heavy: most questions come from the image bank (charts, figures, nets, Venn diagrams, equations) in Numerical, Reasoning and Advanced Quant + Reasoning.'}];
const hasImg=q=>/<img/.test(q.q)||(q.o||[]).some(o=>/<img/.test(String(o)));
const cnt={S1:D.S1.filter(hasImg).length,S2:D.S2.filter(hasImg).length,S4:D.S4.filter(hasImg).length};
const mockMin=m=>m.sections.reduce((a,k)=>a+SEC[k].min,0);
const render=h=>{$('#app').innerHTML=h;window.scrollTo(0,0)};
let M=null;
/* ---------- landing ---------- */
function home(){M=null;document.onkeydown=null;const hist=LSg('hist',[]);const last=hist[hist.length-1];
  const att=k=>{try{const s=P[k].stats();return s.att}catch(e){return 0}};
  render(`<div class="ahead"><div class="logo">NQT</div><div><h1>${esc(CFG.brand)}</h1><small>${esc(CFG.sub)}</small></div></div><div class="wrap">
  <div class="eyebrow">TCS NQT 2027 | ONLINE TEST PRACTICE</div><h2 class="hero">Prepare section by section, then test yourself against the clock</h2>
  <p class="lead">Full mock tests follow the TCS NQT pattern used in this series: five sections, each with its own timer, answers final once submitted. Every section also has its own practice area with unlimited generated questions, figure-based questions and, for coding, an online compiler for C, C++, Java and Python.</p>
  <div class="sec-title">Full mock tests</div><div class="cards">${MOCKS.map(m=>`<div class="mcard"><h3>${m.title}</h3><div class="chips"><span class="chip">${m.sections.length} sections | ${mockMin(m)} min</span></div><div class="chips">${m.sections.map(k=>`<span class="chip">${SEC[k].short} ${SEC[k].q} · ${SEC[k].min}m</span>`).join('')}${m.img?`<span class="chip gold">image-based</span>`:''}</div><p class="grow">${m.desc}</p><button class="abtn" data-mock="${m.id}">Start ${m.title.replace(' (auto-built)','')}</button></div>`).join('')}</div>
  ${last?`<div class="note">Last mock: <b>${last.t}</b> · ${new Date(last.d).toLocaleString()} · score <b>${last.o}%</b> · mocks taken: ${hist.length}</div>`:''}
  <div class="sec-title">Practice by section</div><div class="cards">
   ${secCard('NUM','Numerical Ability','20 Q | 25 min','Percentages, profit and loss, time and work, interest, number system, probability, mensuration and more.',`${NGn(window.NG_NUM)} question types · unlimited`,`${D.S1.length} bank questions`,`${cnt.S1} with figures`)}
   ${secCard('REA','Reasoning Ability','20 Q | 25 min','Series, coding-decoding, blood relations, directions, seating and floor puzzles, syllogisms, Venn, clocks, data sufficiency and figure questions.',`${NGn(window.NG_REA)} question types · unlimited`,`${D.S2.length} bank questions`,`${cnt.S2} with figures`)}
   ${secCard('VER','Verbal Ability','25 tasks | 26 min','New pattern: 20 sentence-completion items, 4 passage-recall tasks and an email. Grammar, vocabulary, recall and writing drills.',`${NGn(window.SG)} sentence types · unlimited`,'Unlimited passages and emails','')}
   ${secCard('ADV','Advanced Quant + Reasoning','14 Q | 25 min','Data interpretation, probability, permutation and combination, number theory, algebra, mensuration, work and pipes, puzzles and syllogisms.',`${NGn(window.NG_ADV)} question types · unlimited`,`${D.S4.length} bank questions`,`${cnt.S4} with figures`)}
   ${secCard('COD','Advanced Coding','2 Q | 90 min','Arrays, strings, hashing, DP, greedy, graphs, matrix and more. Write code in C, C++, Java or Python and run it on the compiler.',`${D.S5.length} problems · hidden test cases`,'C · C++ · Java · Python','')}
  </div>
  <div class="sec-title">Quick figure tests</div><div class="cards">
   ${figCard('figNUM','Figure Test: Numerical','15 questions | 25 min','15 image and equation questions from the bank, same time as the real Numerical section.','Numerical 15Q · 25m')}
   ${figCard('figREA','Figure Test: Reasoning','15 questions | 25 min','15 figure-based reasoning questions (nets, Venn diagrams, figure series, charts) in the real Reasoning time.','Reasoning 15Q · 25m')}
   ${figCard('figADV','Figure Test: Advanced Quant + Reasoning','14 questions | 25 min','14 image and equation questions for the advanced section.','Advanced 14Q · 25m')}
   ${figCard('imgREA','Reasoning Image Test: 50 hard questions','50 questions | 83 min','A long figure-based reasoning test. Take it at 25 minutes per 15 questions.','Reasoning 50Q · 83m')}
  </div>
  <p class="sm mut" style="margin:30px 0 10px">Practice scores are saved in this browser only. Use a current Chrome or Edge on a laptop or desktop for the best experience.</p></div>`);
  $$('[data-mock]').forEach(b=>b.onclick=()=>startMock(MOCKS.find(m=>m.id===b.dataset.mock)));
  $$('[data-sec]').forEach(b=>b.onclick=()=>{const k=b.dataset.sec;if(k==='COD')P.COD.home();else P[k].home()});
  $$('[data-fig]').forEach(b=>b.onclick=()=>figTest(b.dataset.fig))}
const NGn=g=>g&&g.F?g.F.length:0;
const secCard=(k,t,badge,desc,a,b,c)=>{const n=(()=>{try{return P[k].stats().att}catch(e){return 0}})();return `<div class="mcard"><h3>${t}</h3><div class="chips"><span class="chip">${badge}</span></div><p class="grow">${desc}</p><div class="chips"><span class="chip">${a}</span>${b?`<span class="chip">${b}</span>`:''}${c?`<span class="chip gold">${c}</span>`:''}${n?`<span class="chip green">${n} attempted</span>`:''}</div><button class="abtn" data-sec="${k}">Open ${SEC[k].short} practice</button></div>`};
const figCard=(id,t,badge,desc,chip)=>`<div class="mcard"><h3>${t}</h3><div class="chips"><span class="chip">${badge}</span></div><div class="chips"><span class="chip">${chip}</span><span class="chip gold">figure-based</span></div><p class="grow">${desc}</p><button class="abtn" data-fig="${id}">Start ${t.split(':')[0]}</button></div>`;
/* ---------- browser check ---------- */
function ua(){const u=navigator.userAgent;let m;if((m=u.match(/Edg\/(\d+)/)))return {n:'Edge',v:+m[1],min:90};if((m=u.match(/OPR\/(\d+)/)))return {n:'Opera',v:+m[1],min:76};if((m=u.match(/Chrome\/(\d+)/)))return {n:'Chrome',v:+m[1],min:90};if((m=u.match(/Firefox\/(\d+)/)))return {n:'Firefox',v:+m[1],min:90};if((m=u.match(/Version\/(\d+).*Safari/)))return {n:'Safari',v:+m[1],min:14};return {n:'Unknown browser',v:0,min:0}}
async function compat(go,needCompiler){
  const items=[];const add=(label,state,msg)=>items.push({label,state,msg});
  const b=ua();add('Browser',b.v>=b.min&&b.min?'g':(b.min?'y':'y'),`${b.n} ${b.v||''} ${b.v>=b.min&&b.min?'is supported.':'may not be fully supported. Chrome or Edge (latest) is recommended.'}`);
  let st=false;try{localStorage.setItem('arena_t','1');st=localStorage.getItem('arena_t')==='1';localStorage.removeItem('arena_t')}catch(e){}add('Saving progress (browser storage)',st?'g':'y',st?'Available.':'Not available. The test still runs, but progress and the no-repeat memory will not be saved.');
  const feat=typeof fetch==='function'&&typeof Promise==='function'&&typeof AbortController==='function';add('Required browser features',feat?'g':'r',feat?'All present.':'Your browser is too old. Please update it.');
  const w=window.innerWidth;add('Screen size',w>=1000?'g':'y',w>=1000?`${w} px wide.`:`${w} px wide. A laptop or desktop screen is recommended for the test and the code editor.`);
  const tm=await new Promise(r=>{const s=performance.now();setTimeout(()=>r(performance.now()-s),300)});add('Timer accuracy',tm<900?'g':'y',tm<900?'Timers run normally.':'Timers are running slowly. Close other tabs and apps.');
  add('Full screen',document.fullscreenEnabled?'g':'y',document.fullscreenEnabled?'Supported (optional).':'Not available in this window. The test works without it.');
  add('Course player',window.self!==window.top?'g':'g',window.self!==window.top?'Running inside the course player.':'Running directly in the browser.');
  const cIdx=items.length;add('Online compiler (coding section)','p','Checking…');
  const draw=()=>render(`<div class="ahead"><div class="logo">NQT</div><div><h1>${esc(CFG.brand)}</h1><small>${esc(CFG.sub)}</small></div></div><div class="wrap" style="max-width:820px"><div class="card"><span class="tag">BEFORE YOU START</span><h1>Browser compatibility check</h1><p class="mut">No camera or microphone is used. This only checks that your browser can run the test.</p>${items.map(i=>`<div class="chk"><span class="dot ${i.state==='p'?'':i.state}"></span><div><b>${i.label}</b><br><span class="sm mut">${i.msg}</span></div></div>`).join('')}
   <label style="margin-top:14px"><input type="checkbox" id="c_fs" ${document.fullscreenEnabled?'checked':''}> Use full screen during the test (recommended)</label>
   <p style="margin-top:14px"><button class="abtn" id="c_go" ${items.some(i=>i.state==='r')||items[cIdx].state==='p'?'disabled':''}>Start test</button> <button class="abtn alt" id="c_back">Back</button></p></div></div>`);
  draw();$('#c_back').onclick=home;$('#c_go').onclick=async()=>{if($('#c_fs')&&$('#c_fs').checked&&document.documentElement.requestFullscreen){try{await document.documentElement.requestFullscreen()}catch(e){}}go()};
  let ok=[];try{ok=await P.COD.ping()}catch(e){}
  items[cIdx]=ok.length?{label:'Online compiler (coding section)',state:'g',msg:'Reachable ('+ok.join(', ')+'). C, C++, Java and Python can be run.'}:{label:'Online compiler (coding section)',state:needCompiler?'y':'y',msg:'The compiler service could not be reached from this network. Numerical, Reasoning and Verbal work normally; the coding section needs internet access to the compiler.'};
  if(!$('#c_go'))return;draw();$('#c_back').onclick=home;$('#c_go').onclick=async()=>{if($('#c_fs')&&$('#c_fs').checked&&document.documentElement.requestFullscreen){try{await document.documentElement.requestFullscreen()}catch(e){}}go()}}
/* ---------- full mock runner ---------- */
function startMock(m){compat(()=>{M={mock:m,i:0,res:[],start:Date.now()};intro()},m.sections.includes('COD'))}
function intro(){const m=M.mock,k=m.sections[M.i],s=SEC[k];
  render(`<div class="ahead"><div class="logo">NQT</div><div><h1>${esc(m.title)}</h1><small>Section ${M.i+1} of ${m.sections.length}</small></div></div><div class="wrap" style="max-width:820px"><div class="card"><span class="tag">SECTION ${M.i+1} OF ${m.sections.length}</span><h1>${s.name}</h1>
  <div class="chips" style="margin:8px 0"><span class="chip">${s.q}</span><span class="chip">${s.min} minutes</span>${m.img&&k!=='VER'&&k!=='COD'?'<span class="chip gold">image-based</span>':''}</div>
  <ul>${k==='VER'?'<li>20 sentence-completion items, 25 seconds each (auto-advance, no going back).</li><li>Instruction screen, then 4 passage-recall tasks: 30 s to read, 90 s to type.</li><li>Instruction screen, then a 9-minute email.</li>':k==='COD'?'<li>2 problems (one Medium, one Hard) in 90 minutes.</li><li>Write in C, C++, Java or Python. Use Run for your own input and Submit for all hidden test cases.</li><li>Your best submission for each problem counts.</li>':`<li>${s.q.replace(' Q',' questions')}, ${s.min} minutes. Move freely inside the section and mark for review.</li><li>Typed-answer (TITA) questions may appear. There is no negative marking.</li>`}<li><b>Answers are final once the section is submitted.</b> When the timer ends the section is submitted automatically.</li></ul>
  <button class="abtn" id="go">Start section</button></div></div>`);
  $('#go').onclick=()=>runSection(k)}
function runSection(k){const m=M.mock,label=`${m.title.replace(' (auto-built)','')} · Section ${M.i+1}/${m.sections.length}: ${SEC[k].name}`;const done=r=>{M.res.push({k,r});M.i++;M.i<m.sections.length?intro():finishMock()};
  if(k==='NUM'||k==='REA'||k==='ADV'){const n=k==='ADV'?14:20;const opt=m.img?(k==='ADV'?{gen:4,bimg:9,bany:1}:{gen:6,bimg:12,bany:2}):undefined;const items=P[k].makePaper(opt).slice(0,n);P[k].runPaper(items,25,{label,cb:done})}
  else if(k==='VER')P.VER.runVerbal(done,label);else P.COD.runMock(done,label,90)}
const eqv=(a,b)=>{a=String(a).trim().toLowerCase().replace(/[,₹%\s]/g,'');b=String(b).trim().toLowerCase().replace(/[,₹%\s]/g,'');if(a===b)return true;const re=/^[-+]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?$/;if(re.test(a)&&re.test(b)){const x=parseFloat(a),y=parseFloat(b);return Math.abs(x-y)<=0.011||Math.abs(x-y)<=1e-6*Math.max(1,Math.abs(y))}return false};
const isOk=(q,a)=>a!==undefined&&a!==''&&(q.ty==='mcq'?a===q.a:eqv(a,q.a));
function review(r){return r.items.map((q,k)=>{const a=r.ans[k],ok=isOk(q,a);const ya=a===undefined||a===''?'<i>not answered</i>':q.ty==='mcq'?`${L[a]}. ${q.o[a]}`:esc(a);const ca=q.ty==='mcq'?`${L[q.a]}. ${q.o[q.a]}`:esc(q.a);return `<details class="rev"><summary class="${ok?'ok':'bad'}">Q${k+1} · ${ok?'Correct':a===undefined||a===''?'Not answered':'Wrong'} · ${esc(q.t||'')}</summary><div class="qtext">${q.q}</div><p class="sm"><b>Your answer:</b> ${ya}</p><p class="sm"><b>Correct answer:</b> ${ca}</p><p class="sm">${q.e||''}</p></details>`}).join('')}
function finishMock(){const m=M.mock;const secs=M.res.map(({k,r})=>{if(k==='VER')return {k,pct:r.overall,det:`Sentence completion ${r.sc}/20 · recall ${r.prAvg}% · email ${r.es}%`};if(k==='COD')return {k,pct:r.pct,det:r.per.map(x=>`${x.p.title}: ${x.r?x.r.passed+'/'+x.r.total:'not submitted'}`).join(' · ')};return {k,pct:r.p,det:`${r.c}/${r.n} correct · attempted ${r.att}`}});
  const overall=Math.round(secs.reduce((a,s)=>a+s.pct,0)/secs.length);const topics={};M.res.forEach(({k,r})=>{if(r.topics)r.topics.forEach(t=>{const x=topics[t[0]]=topics[t[0]]||[0,0];x[0]+=t[1];x[1]+=t[2]})});
  const tl=Object.entries(topics).filter(v=>v[1][1]>=2).map(([t,v])=>[t,v[0],v[1],Math.round(100*v[0]/v[1])]).sort((a,b)=>a[3]-b[3]);const weak=tl.filter(t=>t[3]<50).slice(0,8);
  const hist=LSg('hist',[]);hist.push({d:Date.now(),t:m.title,o:overall,s:secs.map(s=>s.k+':'+s.pct).join(' ')});LSs('hist',hist.slice(-30));MOCKDONE=true;
  scormReport(overall,`MOCK:${m.id},OVERALL:${overall},`+secs.map(s=>s.k+':'+s.pct).join(','));try{if(document.fullscreenElement)document.exitFullscreen()}catch(e){}
  render(`<div class="ahead"><div class="logo">NQT</div><div><h1>${esc(m.title)}: result</h1><small>${new Date().toLocaleString()}</small></div></div><div class="wrap"><div class="card"><span class="tag">MOCK COMPLETED</span><div class="big">${overall}% <span style="font-size:18px" class="${overall>=CFG.passMark?'ok':'bad'}">${overall>=CFG.passMark?'ABOVE':'BELOW'} the practice target of ${CFG.passMark}%</span></div><p class="mut">Total time used: ${fmt((Date.now()-M.start)/1000*SPEED)} of ${mockMin(m)} min</p>
  <table class="t"><tr><th>Section</th><th>Detail</th><th>Score</th></tr>${secs.map(s=>`<tr><td><b>${SEC[s.k].name}</b></td><td>${s.det}</td><td><b>${s.pct}%</b></td></tr>`).join('')}</table>
  <p style="margin-top:14px"><button class="abtn" id="again">Build a new ${m.title.replace(' (auto-built)','')}</button> <button class="abtn alt" id="back">Back to Arena</button></p></div>
  ${tl.length?`<div class="card"><h2>Topic-wise accuracy</h2><table class="t"><tr><th>Topic</th><th>Correct</th><th>Accuracy</th></tr>${tl.map(t=>`<tr><td>${esc(t[0])}</td><td>${t[1]}/${t[2]}</td><td class="${t[3]>=70?'ok':t[3]<50?'bad':''}">${t[3]}%</td></tr>`).join('')}</table>${weak.length?`<p><b>Focus on:</b> ${weak.map(t=>esc(t[0])).join(', ')}</p>`:''}</div>`:''}
  ${M.res.map(({k,r})=>{if(k==='VER')return `<div class="card"><h2>Verbal review</h2>${r.prs.map((x,i)=>P.VER.recallResult(x.p,x.text,x.s,'Passage '+(i+1))).join('')}<h3>Email</h3>${P.VER.emailResult(r.e.em,r.e.emAns,r.esObj)}<p class="sm mut">Recall and email scores are practice indicators from key-fact and checklist matching, not official marking.</p></div>`;if(k==='COD')return `<div class="card"><h2>Coding review</h2>${r.per.map(x=>`<h3>${esc(x.p.title)} <span class="lv ${x.p.level}">${x.p.level}</span> · ${x.r?x.r.passed+'/'+x.r.total+' test cases':'not submitted'}</h3>${x.r?P.COD.resHTML(x.r):''}`).join('')}</div>`;return `<div class="card"><h2>${SEC[k].name}: answer review</h2>${review(r)}</div>`}).join('')}</div>`);
  $('#again').onclick=()=>startMock(m);$('#back').onclick=home}
/* ---------- figure tests ---------- */
function figTest(id){const spec={figNUM:{k:'NUM',n:15,min:25,t:'Figure Test: Numerical'},figREA:{k:'REA',n:15,min:25,t:'Figure Test: Reasoning'},figADV:{k:'ADV',n:14,min:25,t:'Figure Test: Advanced Quant + Reasoning'},imgREA:{k:'REA',n:50,min:83,t:'Reasoning Image Test: 50 hard questions'}}[id];
  compat(()=>{const items=P[spec.k].figurePaper(spec.n);P[spec.k].runPaper(items,spec.min,{label:spec.t})},false)}
/* ---------- boot ---------- */
window.ARENA={start:()=>{scormInit();home()}};
})();
